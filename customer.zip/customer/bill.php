<?php  
session_start();  
require_once __DIR__ . '/../config/db.php';  
  
// ✅ Check login  
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {  
    header("Location: ../login.php");  
    exit;  
}  
  
$name = $_SESSION['name'];  
  
// ✅ Fetch orders for this customer  
$query = "SELECT * FROM orders WHERE customer_name='$name' ORDER BY order_date DESC";  
$result = mysqli_query($conn, $query);  
  
// ✅ Fetch ordered items  
function getOrderItems($conn, $order_id) {  
    $q = "SELECT item_name, quantity, price FROM order_items WHERE order_id='$order_id'";  
    return mysqli_query($conn, $q);  
}  
?>  
  
<!DOCTYPE html>  
<html lang="en">  
<head>  
<meta charset="UTF-8">  
<title>My Bills | Restaurant System</title>  

<style>  
body {  
  font-family: 'Poppins', sans-serif;  
  margin: 0;  
  background-color: #fff6f6;  
}  

/* ===================== TOP NAVBAR (same as place_order and my_orders) ===================== */  
.navbar {  
  background: #b71c1c;  
  color: white;  
  padding: 15px 30px;  
  display: flex;  
  justify-content: space-between;  
  align-items: center;  
  position: fixed;  
  top: 0; left: 0; right: 0;  
  z-index: 1000;  
}  
.navbar a {  
  background: white;  
  color: #b71c1c;  
  padding: 8px 14px;  
  border-radius: 6px;  
  text-decoration: none;  
  font-weight: 500;  
}  
.navbar a:hover { background: #b71c1c; color:white; }  

/* ===================== SIDEBAR (EXACT COPY from my_orders.php) ===================== */  
.sidebar {  
  width: 230px;  
  background: #fff;  
  border-right: 1px solid #f2c5c5;  
  height: 100vh;  
  position: fixed;  
  top: 60px;  
  left: 0;  
  padding-top: 20px;  
}  
.sidebar a {  
  padding: 12px 22px;  
  display: block;  
  text-decoration: none;  
  color: #333;  
  border-left: 4px solid transparent;  
}  
.sidebar a:hover,  
.sidebar .active {  
  background: #ffeaea;  
  border-left: 4px solid #b71c1c;  
}  

/* ===================== MAIN AREA ===================== */  
.main {  
  margin-left: 250px;  
  margin-top: 90px;  
  padding: 20px;  
  display: flex;  
  flex-direction: column;  
  align-items: center;  
}  
  
/* ===================== BILL CARD DESIGN ===================== */  
.bill-card {  
  background: white;  
  border-radius: 15px;  
  box-shadow: 0 3px 10px rgba(0,0,0,0.1);  
  width: 80%;  
  margin-bottom: 25px;  
  padding: 20px;  
  transition: transform 0.2s;  
}  

.bill-card:hover { transform: scale(1.01); }  

.bill-header {  
  display: flex;  
  justify-content: space-between;  
  border-bottom: 2px dashed #ddd;  
  padding-bottom: 10px;  
  margin-bottom: 15px;  
}  
.bill-header h3 { color: #b71c1c; margin: 0; }  

table {  
  width: 100%;  
  border-collapse: collapse;  
}  
th, td { padding: 8px; text-align: left; }  
th { background: #ffe6e6; color: #b71c1c; }  
td { border-bottom: 1px solid #f0f0f0; }  

.total {  
  text-align: right;  
  font-weight: bold;  
  color: #d32f2f;  
  margin-top: 10px;  
  font-size: 17px;  
}  

/* STATUS BADGES */  
.status {  
  display: inline-block;  
  padding: 5px 10px;  
  border-radius: 20px;  
  color: white;  
  font-size: 13px;  
}  
.status.placed { background: #f57c00; }  
.status.progress { background: #0288d1; }  
.status.delivered { background: #2e7d32; }  
.status.cancelled { background: #c62828; }  
.status.finished { background: #6a1b9a; }  
.status.readytoserve { background: #ff8f00; }  

.print-btn {  
  background: #d32f2f;  
  color: white;  
  padding: 7px 14px;  
  border-radius: 8px;  
  border: none;  
  cursor: pointer;  
  margin-top: 10px;  
  float: right;  
}  
.print-btn:hover { background: #b71c1c; }  

footer {  
  margin-top: 40px;  
  text-align: center;  
  color: #888;  
  font-size: 14px;  
}  
</style>  

<script>  
function printBill(id) {  
  var printContent = document.getElementById('bill-' + id).innerHTML;  
  var win = window.open('', '', 'width=800,height=600');  
  win.document.write('<html><head><title>Print Bill</title>');  
  win.document.write('<style>body{font-family:Poppins,sans-serif;padding:20px;}table{width:100%;border-collapse:collapse;}th,td{padding:8px;}th{background:#ffe6e6;color:#b71c1c;}h2{text-align:center;color:#b71c1c;}</style>');  
  win.document.write('</head><body>');  
  win.document.write(printContent);  
  win.document.write('</body></html>');  
  win.document.close();  
  win.print();  
}  
</script>  
</head>  
  
<body>  
  
<!-- NAVBAR -->  
<div class="navbar">  
  <span>🍽️ Restaurant — Customer</span>  
  <a href="../logout.php">Logout</a>  
</div>  
  
<!-- SIDEBAR -->  
<div class="sidebar">  
  <a href="home.php">🏠 Home</a>  
  <a href="place_order.php">🍴 Place Order</a>  
  <a href="my_orders.php">📦 My Orders</a>  
  <a href="bill.php" class="active">🧾 My Bills</a>  
  <a href="feedback.php">⭐ Feedback</a>  
  <a href="change_password.php">🔑 Change Password</a>  
</div>  
  
<!-- MAIN CONTENT -->  
<div class="main">  
<h2 style="color:#b71c1c;">My Bills</h2>  
  
<?php if (mysqli_num_rows($result) > 0): ?>  
  <?php while ($order = mysqli_fetch_assoc($result)): ?>  
    <?php $items = getOrderItems($conn, $order['id']); ?>  

    <div class="bill-card" id="bill-<?= $order['id'] ?>">  
      <div class="bill-header">  
        <h3>Restaurant Receipt</h3>  
        <span>Order ID: #<?= $order['id'] ?></span>  
      </div>  
  
      <p><b>Date:</b> <?= $order['order_date'] ?> &nbsp; | &nbsp;  
         <b>Table No:</b> <?= $order['table_no'] ?: '-' ?></p>  
  
      <table>  
        <tr>  
          <th>Item Name</th>  
          <th>Qty</th>  
          <th>Price (₹)</th>  
        </tr>  
  
        <?php if (mysqli_num_rows($items) > 0): ?>  
          <?php while ($i = mysqli_fetch_assoc($items)): ?>  
            <tr>  
              <td><?= $i['item_name'] ?></td>  
              <td><?= $i['quantity'] ?></td>  
              <td><?= $i['price'] ?></td>  
            </tr>  
          <?php endwhile; ?>  
        <?php else: ?>  
          <tr><td colspan="3">No items found.</td></tr>  
        <?php endif; ?>  
      </table>  
  
      <div class="total">Total: ₹<?= number_format($order['total_price'], 2) ?></div>  
  
      <p><b>Status:</b>  
        <span class="status <?= strtolower(str_replace(' ', '', $order['status'])) ?>">  
          <?= $order['status'] ?>  
        </span>  
      </p>  
  
      <button class="print-btn" onclick="printBill(<?= $order['id'] ?>)">🖨️ Print Bill</button>  
    </div>  
  <?php endwhile; ?>  
<?php else: ?>  
  <h3>No bills found.</h3>  
<?php endif; ?>  
  
<footer>© <?= date('Y') ?> Restaurant Management System | Customer Panel</footer>  
</div>  
</body>  
</html>