<?php
// ✅ Enable error reporting for debugging (you can remove later)
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Ensure only customers can access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit;
}

$name = $_SESSION['name'];
$message = "";

// ✅ Handle Feedback Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = intval($_POST['rating']);
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    // Insert feedback data
    $sql = "INSERT INTO feedback (customer_name, rating, comment, date_submitted)
            VALUES ('$name', '$rating', '$comment', NOW())";

    if (mysqli_query($conn, $sql)) {
        $message = "✅ Thank you for your feedback!";
    } else {
        $message = "❌ Something went wrong. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Customer Feedback | Restaurant</title>
<style>
body {
  font-family: 'Segoe UI', sans-serif;
  margin: 0;
  background: #fff5f5;
  color: #333;
}
.navbar {
  background: #b71c1c;
  color: white;
  padding: 12px 25px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.navbar h1 {
  font-size: 20px;
  margin: 0;
}
.navbar a {
  background: white;
  color: #b71c1c;
  padding: 8px 14px;
  border-radius: 6px;
  text-decoration: none;
  font-weight: 500;
}
.sidebar {
  width: 230px;
  background: #fff;
  border-right: 1px solid #f2c5c5;
  height: 100vh;
  position: fixed;
  top: 50px;
  left: 0;
  padding-top: 20px;
}
.sidebar a {
  display: block;
  color: #333;
  padding: 12px 22px;
  text-decoration: none;
  border-left: 4px solid transparent;
  transition: 0.3s;
}
.sidebar a:hover, .sidebar .active {
  background: #ffeaea;
  border-left: 4px solid #b71c1c;
}
.main {
  margin-left: 250px;
  padding: 40px;
}
h2 {
  color: #b71c1c;
  font-size: 24px;
  margin-bottom: 20px;
}
.feedback-box {
  background: #fff;
  border: 1px solid #f3cfcf;
  border-radius: 10px;
  padding: 25px;
  box-shadow: 0 2px 5px rgba(0,0,0,0.05);
  max-width: 500px;
}
.rating {
  display: flex;
  justify-content: center;
  margin-bottom: 15px;
  flex-direction: row-reverse;
}
.rating input {
  display: none;
}
.rating label {
  font-size: 35px;
  color: #ddd;
  cursor: pointer;
  transition: color 0.3s;
}
.rating input:checked ~ label,
.rating label:hover,
.rating label:hover ~ label {
  color: #fbc02d;
}
textarea {
  width: 100%;
  padding: 10px;
  border-radius: 6px;
  border: 1px solid #f3cfcf;
  resize: none;
}
.submit-btn {
  margin-top: 15px;
  padding: 10px 15px;
  border: none;
  border-radius: 6px;
  background: #b71c1c;
  color: white;
  font-size: 16px;
  cursor: pointer;
}
.submit-btn:hover {
  background: #a31515;
}
.message {
  margin-top: 15px;
  font-weight: 500;
  color: #2e7d32;
  text-align: center;
}
</style>
</head>
<body>

<!-- ✅ Navbar -->
<div class="navbar">
  <h1>🍽 Restaurant — Customer</h1>
  <a href="../logout.php">Logout</a>
</div>

<!-- ✅ Sidebar -->
<div class="sidebar">
  <a href="home.php">🏠 Home</a>
  <a href="place_order.php">🍴 Place Order</a>
  <a href="my_orders.php">📦 My Orders</a>
  
  <a href="bill.php">🧾 My Bill</a>
  <a href="feedback.php" class="active">⭐ Feedback</a>
  <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- ✅ Main Section -->
<div class="main">
  <h2>⭐ Give Your Feedback</h2>

  <div class="feedback-box">
    <form method="POST">
      <div class="rating">
        <input type="radio" name="rating" id="star5" value="5" required><label for="star5">★</label>
        <input type="radio" name="rating" id="star4" value="4"><label for="star4">★</label>
        <input type="radio" name="rating" id="star3" value="3"><label for="star3">★</label>
        <input type="radio" name="rating" id="star2" value="2"><label for="star2">★</label>
        <input type="radio" name="rating" id="star1" value="1"><label for="star1">★</label>
      </div>

      <textarea name="comment" rows="4" placeholder="Write your feedback here..."></textarea>
      <button type="submit" class="submit-btn">Submit Feedback</button>
    </form>

    <?php if ($message): ?>
      <p class="message"><?= $message ?></p>
    <?php endif; ?>
  </div>
</div>
</body>
</html>