<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Check login
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {
    header("Location: ../login.php");
    exit;
}

$name = $_SESSION['name'];
$success = $error = "";

// Handle password change
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $old_pass = $_POST['old_password'];
    $new_pass = $_POST['new_password'];
    $confirm_pass = $_POST['confirm_password'];

    $res = mysqli_query($conn, "SELECT password FROM users WHERE email='$name'");
    $row = mysqli_fetch_assoc($res);

    if ($row && $row['password'] == $old_pass) {
        if ($new_pass == $confirm_pass) {
            if (mysqli_query($conn, "UPDATE users SET password='$new_pass' WHERE email='$name'")) {
                $success = "✅ Password changed successfully!";
            } else {
                $error = "⚠️ Error updating password. Try again.";
            }
        } else {
            $error = "❌ New and Confirm Password do not match!";
        }
    } else {
        $error = "❌ Old password is incorrect!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Change Password | Restaurant System</title>

<style>
body {
  font-family: 'Poppins', sans-serif;
  margin: 0;
  background-color: #fff6f6;
}

/* ===================== NAVBAR SAME ===================== */
.navbar {
  background: #b71c1c;
  color: white;
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: fixed;
  top: 0; left: 0; right: 0;
  z-index: 1000;
}
.navbar a {
  background: white;
  color: #b71c1c;
  padding: 8px 14px;
  border-radius: 6px;
  text-decoration: none;
  font-weight: 500;
}
.navbar a:hover { background: #b71c1c; color: white; }

/* ===================== UPDATED SIDEBAR (same as other pages) ===================== */
.sidebar {
  width: 230px;
  background: #fff;
  border-right: 1px solid #f2c5c5;
  height: 100vh;
  position: fixed;
  top: 60px;
  left: 0;
  padding-top: 20px;
}
.sidebar a {
  padding: 12px 22px;
  display: block;
  text-decoration: none;
  color: #333;
  border-left: 4px solid transparent;
}
.sidebar a:hover,
.sidebar .active {
  background: #ffeaea;
  border-left: 4px solid #b71c1c;
}

/* ===================== MAIN ===================== */
.main {
  margin-left: 250px;
  margin-top: 90px;
  padding: 20px;
  text-align: center;
}

/* ===================== FORM CARD ===================== */
.form-container {
  background: white;
  width: 400px;
  margin: 40px auto;
  padding: 30px;
  border-radius: 12px;
  box-shadow: 0 3px 10px rgba(0,0,0,0.1);
  text-align: left;
}
.form-container h2 {
  text-align: center;
  color: #b71c1c;
  margin-bottom: 20px;
}
label {
  margin-bottom: 5px;
  display: block;
  font-weight: 500;
}
input[type="password"] {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border-radius: 6px;
  border: 1px solid #ccc;
}
button {
  width: 100%;
  padding: 10px;
  background: #b71c1c;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
}
button:hover { background: #8c1010; }

/* ===================== MESSAGES ===================== */
.msg {
  padding: 10px;
  border-radius: 6px;
  margin-bottom: 15px;
  text-align: center;
}
.success { background: #c8e6c9; color: #2e7d32; }
.error { background: #ffcdd2; color: #c62828; }

footer {
  margin-top: 30px;
  color: #888;
  font-size: 14px;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
  <span>🍽️ Restaurant — Customer</span>
  <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR SAME AS OTHER PAGES -->
<div class="sidebar">
  <a href="home.php">🏠 Home</a>
  <a href="place_order.php">🍴 Place Order</a>
  <a href="my_orders.php">📦 My Orders</a>
  <a href="bill.php">🧾 My Bills</a>
  <a href="feedback.php">⭐ Feedback</a>
  <a href="change_password.php" class="active">🔑 Change Password</a>
</div>

<!-- MAIN -->
<div class="main">

  <div class="form-container">
    <h2>Change Password</h2>

    <?php if ($success): ?>
      <div class="msg success"><?= $success ?></div>
    <?php elseif ($error): ?>
      <div class="msg error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
      <label>Old Password:</label>
      <input type="password" name="old_password" required>

      <label>New Password:</label>
      <input type="password" name="new_password" required>

      <label>Confirm Password:</label>
      <input type="password" name="confirm_password" required>

      <button type="submit">Update Password</button>
    </form>
  </div>

  <footer>© <?= date('Y') ?> Restaurant Management System | Customer Panel</footer>
</div>

</body>
</html>