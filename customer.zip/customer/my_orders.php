<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Check login
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'customer') {
    header("Location: ../login.php");
    exit;
}

$name = $_SESSION['name'];

// ---------------------
// HANDLE CANCEL REQUEST
// ---------------------
if (isset($_POST['cancel_order'])) {

    $order_id = intval($_POST['order_id']);

    // Update order status
    mysqli_query($conn, "UPDATE orders SET status='Cancelled' WHERE id=$order_id");

    // Free the table
    $table_res = mysqli_fetch_assoc(mysqli_query($conn, "SELECT table_no FROM orders WHERE id=$order_id"));
    if ($table_res) {
        $t = $table_res['table_no'];
        mysqli_query($conn, "UPDATE tables SET status='Available', reserved_by=NULL WHERE table_no='$t'");
    }

    header("Location: my_orders.php");
    exit;
}

// Fetch orders
$query = "SELECT * FROM orders WHERE customer_name='$name' ORDER BY order_date DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Orders | Restaurant</title>

<style>
/* SAME THEME AS place_order.php */
body { font-family: 'Segoe UI', sans-serif; margin: 0; background: #fff5f5; color: #333; }

/* TOP NAVBAR (Same as place_order.php) */
.navbar {
  background: #b71c1c; color: white;
  padding: 12px 25px; display: flex; justify-content: space-between;
  align-items: center; position: fixed; top: 0; left: 0; right: 0; z-index: 1000;
}
.navbar h1 { font-size: 20px; margin: 0; }
.navbar a {
  background: white; color: #b71c1c; padding: 8px 14px;
  border-radius: 6px; text-decoration: none; font-weight: 500;
}
.navbar a:hover { background: #b71c1c; color: white; }

/* SIDEBAR — EXACT COPY FROM place_order.php */
.sidebar {
  width: 230px; background: #fff; border-right: 1px solid #f2c5c5;
  height: 100vh; position: fixed; top: 50px; left: 0; padding-top: 20px;
}
.sidebar a {
  padding: 12px 22px; display: block; text-decoration: none;
  color: #333; border-left: 4px solid transparent;
}
.sidebar a:hover,
.sidebar .active {
  background: #ffeaea; border-left: 4px solid #b71c1c;
}

/* MAIN CONTENT */
.main { margin-left: 250px; padding: 90px 40px 40px; }
h2 { color: #b71c1c; font-size: 24px; margin-bottom: 10px; }

/* TABLE */
table {
  width: 100%; border-collapse: collapse; background: #fff;
  border: 1px solid #f2c5c5; border-radius: 10px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}
th, td {
  padding: 12px; text-align: center;
  border-bottom: 1px solid #f2c5c5;
}
th { background: #ffeaea; color: #b71c1c; }

/* STATUS COLORS */
.status { font-weight: 700; }
.status-placed { color: #8d6e63; }
.status-inprogress { color: #6a1b9a; }
.status-readytoserve { color: #ff8f00; }
.status-finished { color: #0277bd; }
.status-delivered { color: #2e7d32; }
.status-cancelled { color: #c62828; }

/* ACTION BUTTONS */
.action-btn {
  border: none; padding: 6px 12px; border-radius: 8px;
  cursor: pointer; color: #fff; font-weight: 500; margin: 2px;
}
.view { background: #1976d2; }
.cancel { background: #d32f2f; }
.cancel.disabled { background: #bfbfbf; cursor:not-allowed; }

footer { text-align:center; margin-top:30px; color:#888; }
</style>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
  <h1>📦 My Orders — <?= htmlspecialchars($name); ?></h1>
  <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR (MATCHING place_order.php EXACTLY) -->
<div class="sidebar">
  <a href="home.php">🏠 Home</a>
  <a href="place_order.php">🍴 Place Order</a>
  <a href="my_orders.php" class="active">📦 My Orders</a>
  <a href="bill.php">🧾 My Bill</a>
  <a href="feedback.php">⭐ Feedback</a>
  <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN -->
<div class="main">
  <h2>My Orders</h2>

  <table>
    <tr>
      <th>Order ID</th>
      <th>Date</th>
      <th>Table</th>
      <th>Total Items</th>
      <th>Total Price (₹)</th>
      <th>Status</th>
      <th>Action</th>
    </tr>

    <?php while ($row = mysqli_fetch_assoc($result)): ?>
      <?php
        $status = trim($row['status']);
        $class = "status-" . strtolower(str_replace(" ", "", $status));
      ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= $row['order_date'] ?></td>
        <td><?= $row['table_no'] ?></td>
        <td><?= $row['total_items'] ?></td>
        <td><?= $row['total_price'] ?></td>

        <td><span class="status <?= $class ?>"><?= $status ?></span></td>

        <td>
          <a href="view_order.php?id=<?= $row['id'] ?>" class="action-btn view">View</a>

          <?php if ($status === "Placed"): ?>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="order_id" value="<?= $row['id'] ?>">
              <button type="submit" name="cancel_order" class="action-btn cancel">Cancel</button>
            </form>
          <?php else: ?>
            <button class="action-btn cancel disabled" disabled>Cancel</button>
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>

  <footer>© <?= date('Y') ?> Restaurant Management System</footer>
</div>

</body>
</html>