<?php  
session_start();  
require_once __DIR__ . '/../config/db.php';  

// ✅ Check if customer is logged in  
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {  
    header("Location: ../login.php");  
    exit;  
}  

$name = $_SESSION['name'];  
$message = "";  

// ✅ Handle order submission  
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['table_no']) && !empty($_POST['items'])) {  
    $table_no   = intval($_POST['table_no']);  
    $items      = $_POST['items'];          // selected item IDs  
    $quantities = $_POST['quantity'];       // quantity per item ID  
    $total_price = 0;  

    // ➤ Calculate total using special_price when today_special = 1  
    foreach ($items as $item_id) {  
        $item_id = intval($item_id);  
        $qty     = intval($quantities[$item_id]);  

        $q = mysqli_query($conn, "SELECT price, special_price, today_special FROM menu_items WHERE id=$item_id");  
        if ($q && $row = mysqli_fetch_assoc($q)) {  
            $effective_price = ($row['today_special'] && $row['special_price'] > 0)  
                               ? $row['special_price']  
                               : $row['price'];  

            $total_price += $effective_price * $qty;  
        }  
    }  

    // ➤ Insert order  
    $query = "INSERT INTO orders (customer_name, table_no, total_items, total_price, status, order_date)  
              VALUES ('$name', $table_no, " . count($items) . ", $total_price, 'Placed', NOW())";  

    if (mysqli_query($conn, $query)) {  
        $order_id = mysqli_insert_id($conn);  

        // ➤ Insert each item in order_items with effective (offer) price  
        foreach ($items as $item_id) {  
            $item_id = intval($item_id);  
            $qty     = intval($quantities[$item_id]);  

            $menuData = mysqli_query($conn, "SELECT category, price, special_price, today_special  
                                             FROM menu_items WHERE id=$item_id");  
            $item = mysqli_fetch_assoc($menuData);  

            $item_name = mysqli_real_escape_string($conn, $item['category']);  
            $effective_price = ($item['today_special'] && $item['special_price'] > 0)  
                               ? $item['special_price']  
                               : $item['price'];  

            mysqli_query($conn, "INSERT INTO order_items (order_id, item_name, quantity, price)  
                                 VALUES ($order_id, '$item_name', $qty, $effective_price)");  
        }  

        // ➤ Reserve table  
        mysqli_query($conn, "UPDATE tables SET status='Reserved', reserved_by='$name' WHERE table_no=$table_no");  

        $message = "✅ Order placed successfully! Table No: $table_no | Total: ₹$total_price";  
    } else {  
        $message = "❌ Error placing order. Try again.";  
    }  
}  

// ✅ Fetch ALL tables (so customer can see which are reserved/occupied)  
$tables_res = mysqli_query($conn, "SELECT * FROM tables ORDER BY table_no ASC");  
$tables = [];  
while ($row = mysqli_fetch_assoc($tables_res)) {  
    $tables[] = $row;  
}  

// ✅ Fetch categories  
$cat_res = mysqli_query($conn, "SELECT id, name FROM categories ORDER BY name");  
$categories = [];  
while ($row = mysqli_fetch_assoc($cat_res)) {  
    $categories[] = $row;  
}  

// ✅ Fetch menu items (with new columns)  
$menu_res = mysqli_query($conn, "SELECT * FROM menu_items ORDER BY category_id");  
$menu_items = [];  
while ($row = mysqli_fetch_assoc($menu_res)) {  
    $menu_items[] = $row;  
}  
?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
<meta charset="UTF-8">  
<title>Place Order | Restaurant</title>  
<style>  
body { font-family: 'Segoe UI', sans-serif; margin: 0; background: #fff5f5; color: #333; }  

/* NAVBAR */  
.navbar {  
  background: #b71c1c; color: white;  
  padding: 12px 25px; display: flex; justify-content: space-between;  
  align-items: center; position: fixed; top: 0; left: 0; right: 0; z-index: 1000;  
}  
.navbar h1 { font-size: 20px; margin: 0; }  
.navbar a { background: white; color: #b71c1c; padding: 8px 14px; border-radius: 6px; text-decoration: none; font-weight: 500; }  
.navbar a:hover { background: #b71c1c; color: white; }  

/* SIDEBAR */  
.sidebar {  
  width: 230px; background: #fff; border-right: 1px solid #f2c5c5;  
  height: 100vh; position: fixed; top: 50px; left: 0; padding-top: 20px;  
}  
.sidebar a { padding: 12px 22px; display: block; text-decoration: none;  
  color: #333; border-left: 4px solid transparent; }  
.sidebar a:hover, .sidebar .active { background: #ffeaea; border-left: 4px solid #b71c1c; }  

/* MAIN */  
.main { margin-left: 250px; padding: 90px 40px 40px; }  
h2 { color: #b71c1c; font-size: 24px; margin-bottom: 10px; }  

form {  
  background: #fff; border: 1px solid #f2c5c5; padding: 25px;  
  border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.08);  
  max-width: 1100px;  
}  

label { font-weight: bold; color: #b71c1c; margin-bottom: 8px; display: block; }  

select, input[type="number"] {  
  width: 100%; padding: 10px; border: 1px solid #f2c5c5; border-radius: 6px; margin-bottom: 20px;  
}  

.message { background: #ffeaea; color: #b71c1c; padding: 10px; border-radius: 6px; margin-bottom: 20px; text-align: center; }  

/* TABLE STATUS COLORS */  
.status-available { color: green; }  
.status-reserved { color: red; }  
.status-occupied { color: orange; }  
.status-cleaning { color: #0288d1; }  

/* CATEGORY BAR */  
.category-bar {  
  display:flex;  
  flex-wrap:wrap;  
  gap:8px;  
  margin-bottom:18px;  
}  
.cat-btn {  
  border:1px solid #f2c5c5;  
  background:#fff;  
  padding:6px 12px;  
  border-radius:20px;  
  font-size:13px;  
  cursor:pointer;  
}  
.cat-btn.active {  
  background:#b71c1c;  
  color:#fff;  
  border-color:#b71c1c;  
}  

/* FLEX LAYOUT FOR MENU + SUMMARY */  
.order-layout { display: flex; gap: 20px; align-items: flex-start; }  
.menu-section { flex: 2; }  
.summary-section {  
  flex: 1; background: #fff8f8; border: 1px solid #f2c5c5;  
  border-radius: 10px; padding: 15px; box-shadow: 0 1px 4px rgba(0,0,0,0.05);  
  max-height: 480px; display:flex; flex-direction:column;  
}  

/* MENU CARDS */  
.menu-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }  
.menu-card { background: #fff8f8; border: 1px solid #f2c5c5; border-radius: 10px; padding: 10px; text-align: center; }  
.menu-card img { width: 100%; height: 120px; object-fit: cover; border-radius: 10px; }  
.menu-card p { font-size: 13px; color: #666; }  

.price-line { margin-top:4px; font-size:13px; }  
.old-price { text-decoration: line-through; color:#888; margin-right:6px; }  
.special-price { color:#b71c1c; font-weight:600; }  
.badge-special {  
  display:inline-block;  
  background:#ffd54f;  
  color:#8d6e00;  
  font-size:11px;  
  padding:2px 6px;  
  border-radius:10px;  
  margin-left:4px;  
}  

/* CURRENT ORDER SUMMARY */  
.summary-section h3 { text-align: center; color: #b71c1c; margin-top:0; }  
.summary-table { width: 100%; border-collapse: collapse; font-size:13px; }  
.summary-table th, .summary-table td { border-bottom: 1px solid #f2c5c5; padding: 6px; text-align: center; }  
.summary-total { font-weight: bold; margin-top: 8px; text-align: right; color: #b71c1c; }  

.place-btn {  
  margin-top:12px;  
  width:100%;  
  background:#b71c1c;  
  color:#fff;  
  border:none;  
  padding:10px 0;  
  border-radius:6px;  
  font-size:15px;  
  cursor:pointer;  
}  
.place-btn:hover { background:#d32f2f; } 
/* SPECIAL BUTTON STYLE */
.special-btn {
  background: #ffcc00 !important;
  color: #000;
  font-weight: 700;
  border: 2px solid #b39500;
  box-shadow: 0 0 8px rgba(255,204,0,0.6);
}

.special-btn:hover {
  background: #ffdb4d !important;
  box-shadow: 0 0 12px rgba(255,204,0,0.9);
}

/* SPECIAL ITEM CARD STYLE */
.menu-card.special-card {
  border: 2px solid #ffcc00;
  box-shadow: 0 0 10px rgba(255,204,0,0.6);
  position: relative;
}

/* 🔥 Top-right special ribbon */
.menu-card.special-card::after {
  content: "🔥 Special";
  position: absolute;
  top: 6px;
  right: 6px;
  background: #ffcc00;
  color: #000;
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 6px;
  font-weight: 600;
}

/* CATEGORY TRANSITIONS */
.menu-card {
  transition: transform .25s ease, opacity .25s ease;
}

.menu-card.hidden {
  opacity: 0;
  transform: scale(0.9);
  pointer-events: none;
}

.menu-card.show {
  opacity: 1;
  transform: scale(1);
}
/* FIX QUANTITY BOX STYLE */
.qty-input {
  width: 60px !important;
  padding: 6px !important;
  text-align: center;
  border-radius: 6px;
  border: 1px solid #d0b3b3;
  font-size: 14px;
  margin-top: 6px;
}

/* Remove arrows for cleaner UI (optional) */
.qty-input::-webkit-inner-spin-button,
.qty-input::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
</style>  
</head>  
<body>  

<div class="navbar">  
  <h1>🍽 Restaurant — Customer</h1>  
  <a href="../logout.php">Logout</a>  
</div>  

<div class="sidebar">  
  <a href="home.php">🏠 Home</a>  
  <a href="place_order.php" class="active">🍴 Place Order</a>  
  <a href="my_orders.php">📦 My Orders</a>  
  <a href="bill.php">🧾 My Bill</a>  
  <a href="feedback.php">⭐ Feedback</a>  
  <a href="change_password.php">🔑 Change Password</a>  
</div>  

<div class="main">  
  <h2>🧾 Place Your Order</h2>  

  <?php if ($message): ?>  
    <div class="message"><?= $message ?></div>  
  <?php endif; ?>  

  <form method="POST">  

    <!-- SELECT TABLE (show all statuses, but only Available selectable) -->  
    <label>Select Table</label>  
    <select name="table_no" required>  
      <option value="">-- Choose Table --</option>  
      <?php foreach ($tables as $t): ?>  
        <?php  
          $status   = strtolower($t['status']);  
          $disabled = ($status != 'available') ? 'disabled' : '';  
          $class    = "status-$status";  
          $label    = ucfirst($t['status']);  
          $extra    = ($t['reserved_by']) ? " (".$t['reserved_by'].")" : "";  
        ?>  
        <option value="<?= $t['table_no'] ?>" <?= $disabled ?> class="<?= $class ?>">  
          Table <?= $t['table_no'] ?> — <?= $label . $extra ?>  
        </option>  
      <?php endforeach; ?>  
    </select>  

    <!-- CATEGORY / TODAY SPECIAL BAR -->  
    <label>Select Category / Today's Special</label>
<div class="category-bar">

  <!-- ⭐ TODAY'S SPECIAL FIRST -->
  <button type="button" class="cat-btn special-btn active" data-filter="today">
    ⭐ Today’s Special
  </button>

  <!-- Regular category buttons -->
  <button type="button" class="cat-btn" data-filter="all">All Items</button>

  <?php foreach ($categories as $cat): ?>
    <button type="button" class="cat-btn" data-filter="cat<?= $cat['id'] ?>">
      <?= htmlspecialchars($cat['name']) ?>
    </button>
  <?php endforeach; ?>

</div>

    <!-- MENU + CURRENT ORDER LAYOUT -->  
    <div class="order-layout">  

      <!-- LEFT: MENU ITEMS -->  
      <div class="menu-section">  
        <div class="menu-grid">  
          <?php foreach ($menu_items as $m): ?>  
            <?php  
              $imagePath = !empty($m['image'])  
                  ? "../assets/images/menu/" . htmlspecialchars($m['image'])  
                  : "../assets/images/menu/default-food.jpg";  

              $isSpecial = ($m['today_special'] == 1);  
              $effectivePrice = ($isSpecial && $m['special_price'] > 0)  
                                ? $m['special_price']  
                                : $m['price'];  
            ?>  

            <div class="menu-card"  
                 data-category-id="cat<?= $m['category_id'] ?>"  
                 data-today="<?= $isSpecial ? '1' : '0' ?>"  
                 data-price="<?= $effectivePrice ?>">  

              <img src="<?= $imagePath ?>" alt="<?= htmlspecialchars($m['category']) ?>">  

              <label>  
                <input type="checkbox" class="item-checkbox" name="items[]" value="<?= $m['id'] ?>">  
                <?= htmlspecialchars($m['category']) ?>  
              </label>  

              <p><?= htmlspecialchars($m['description'] ?: 'Delicious item!') ?></p>  

              <div class="price-line">  
                <?php if ($isSpecial && $m['special_price'] > 0): ?>  
                  <span class="old-price">₹<?= $m['price'] ?></span>  
                  <span class="special-price">₹<?= $m['special_price'] ?></span>  
                  <span class="badge-special">Today’s Special</span>  
                <?php else: ?>  
                  <span>₹<?= $m['price'] ?></span>  
                <?php endif; ?>  
              </div>  

              <input type="number" class="qty-input" name="quantity[<?= $m['id'] ?>]" min="1" max="10" value="1">  
            </div>  
          <?php endforeach; ?>  
        </div>  
      </div>  

      <!-- RIGHT: CURRENT ORDER SUMMARY + PLACE ORDER BUTTON -->  
      <div class="summary-section">  
        <h3>🧾 Current Order</h3>  
        <table class="summary-table">  
          <thead>  
            <tr><th>Item</th><th>Qty</th><th>Amount</th></tr>  
          </thead>  
          <tbody id="summaryBody"></tbody>  
        </table>  
        <div class="summary-total">Total: <span id="orderTotal">₹0.00</span></div>  

        <!-- 👉 Place Order button BELOW current order table -->  
        <button type="submit" class="place-btn">✅ Place Order</button>  
      </div>  

    </div>  

  </form>  
</div>  

<script>
// === CATEGORY / TODAY SPECIAL FILTER ===
document.querySelectorAll('.cat-btn').forEach(btn => {
  btn.addEventListener('click', function () {
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    this.classList.add('active');

    const filter = this.dataset.filter;
    document.querySelectorAll('.menu-card').forEach(card => {
      const catId   = card.dataset.categoryId;
      const isToday = card.dataset.today === '1';
      let show = false;

      if (filter === 'all') {
        show = true;
      } else if (filter === 'today') {
        show = isToday;
      } else {
        show = (catId === filter);
      }

      card.style.display = show ? 'block' : 'none';
    });

    // After filtering, recompute current order (in case some visible/hidden changed)
    updateSummary();
  });
});

// === CURRENT ORDER SUMMARY (uses effective price) ===
function updateSummary() {
  const tbody = document.getElementById('summaryBody');
  const totalSpan = document.getElementById('orderTotal');
  tbody.innerHTML = '';
  let total = 0;

  document.querySelectorAll('.menu-card').forEach(card => {
    const checkbox = card.querySelector('.item-checkbox');
    const qtyInput = card.querySelector('.qty-input');

    if (!checkbox.checked) return;

    const name  = card.querySelector('label').innerText.trim();
    const price = parseFloat(card.dataset.price);
    const qty   = parseInt(qtyInput.value) || 1;
    const lineTotal = price * qty;
    total += lineTotal;

    const tr = document.createElement('tr');
    tr.innerHTML =
      '<td>' + name + '</td>' +
      '<td>' + qty + '</td>' +
      '<td>₹' + lineTotal.toFixed(2) + '</td>';
    tbody.appendChild(tr);
  });

  totalSpan.textContent = '₹' + total.toFixed(2);
}

// Attach listeners for summary updates
document.querySelectorAll('.item-checkbox, .qty-input').forEach(el => {
  el.addEventListener('change', updateSummary);
  el.addEventListener('input', updateSummary);
});

// Initial call
updateSummary();
</script>

</body>  
</html>