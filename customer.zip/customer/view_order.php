<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Check customer login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit;
}

$customer = $_SESSION['name'];

// Validate order ID
if (!isset($_GET['id'])) {
    header("Location: my_orders.php");
    exit;
}

$order_id = intval($_GET['id']);

// Fetch order
$order_query = mysqli_query($conn, "
    SELECT * FROM orders 
    WHERE id = $order_id AND customer_name = '$customer'
");

$order = mysqli_fetch_assoc($order_query);

if (!$order) {
    echo "<script>alert('Invalid order!'); window.location='my_orders.php';</script>";
    exit;
}

// Fetch ordered items
$order_items = mysqli_query($conn, "SELECT * FROM order_items WHERE order_id = $order_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Order Details | Restaurant System</title>

<style>
:root {
  --brand: #b71c1c;
  --light: #fff6f6;
  --border: #f2c5c5;
}

* { box-sizing: border-box; font-family: 'Poppins', sans-serif; }

body {
  margin: 0;
  background: var(--light);
  color: #333;
}

/* HEADER */
.header {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 64px;
  background: var(--brand);
  color: #fff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 22px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
.header h1 {
  margin: 0;
  font-size: 20px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 10px;
}
.header a {
  background: #fff;
  color: var(--brand);
  padding: 8px 14px;
  border-radius: 8px;
  text-decoration: none;
  font-weight: 600;
}

/* SIDEBAR */
.sidebar {
  position: fixed;
  top: 64px;
  left: 0;
  width: 220px;
  bottom: 0;
  background: #fff;
  border-right: 1px solid #eee;
  padding-top: 10px;
}
.sidebar a {
  display: block;
  padding: 12px 20px;
  color: var(--brand);
  font-weight: 500;
  text-decoration: none;
}
.sidebar a:hover { background: #ffe6e6; }
.sidebar a.active {
  background: var(--brand);
  color: #fff;
  border-left: 6px solid #8f1919;
}

/* MAIN CONTENT */
.main {
  margin-left: 240px;
  margin-top: 80px;
  padding: 30px;
}
h2 {
  color: var(--brand);
  font-size: 22px;
  margin-bottom: 20px;
}

/* BOX */
.details-box {
  background: #fff;
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 24px;
  width: 800px;
  max-width: 95%;
  box-shadow: 0 2px 10px rgba(0,0,0,0.05);
}
.details-box p { font-size: 15px; margin: 8px 0; }
.details-box strong { color: var(--brand); }

/* TABLE */
.table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}
.table th, .table td {
  border: 1px solid var(--border);
  padding: 10px;
  text-align: center;
}
.table th {
  background: var(--brand);
  color: #fff;
}

/* BACK BUTTON */
.back-btn {
  background: var(--brand);
  color: #fff;
  border: none;
  padding: 10px 18px;
  border-radius: 8px;
  margin-top: 22px;
  cursor: pointer;
  font-weight: 600;
}
.back-btn:hover { background: #8f1919; }

footer {
  margin-top: 40px;
  text-align: center;
  color: #666;
}
</style>

</head>
<body>

<!-- HEADER -->
<div class="header">
  <h1>🍽 Restaurant — Customer</h1>
  <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
  <a href="home.php">🏠 Home</a>
  <a href="place_order.php">🛒 Place Order</a>
  <a href="my_orders.php" class="active">📦 My Orders</a>
  <a href="bill.php">💰 My Bills</a>
  <a href="feedback.php">💬 Feedback</a>
  <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN -->
<div class="main">
  <h2>📄 Order Details</h2>

  <div class="details-box">
    <p><strong>Order ID:</strong> <?= $order['id'] ?></p>
    <p><strong>Table No:</strong> <?= $order['table_no'] ?></p>
    <p><strong>Total Items:</strong> <?= $order['total_items'] ?></p>
    <p><strong>Total Price (₹):</strong> <?= $order['total_price'] ?></p>
    <p><strong>Status:</strong> <?= ucfirst($order['status']) ?></p>
    <p><strong>Date:</strong> <?= $order['order_date'] ?></p>

    <h3 style="color:#b71c1c; margin-top:20px;">🧾 Ordered Items</h3>

    <table class="table">
      <tr>
        <th>Item Name</th>
        <th>Quantity</th>
        <th>Price (₹)</th>
      </tr>

      <?php while ($it = mysqli_fetch_assoc($order_items)): ?>
      <tr>
        <td><?= htmlspecialchars($it['item_name']) ?></td>
        <td><?= $it['quantity'] ?></td>
        <td><?= $it['price'] ?></td>
      </tr>
      <?php endwhile; ?>
    </table>

    <button class="back-btn" onclick="window.location='my_orders.php'">← Back to Orders</button>
  </div>

  <footer>© <?= date('Y') ?> Restaurant Management System</footer>
</div>

</body>
</html>