<?php  
session_start();
require_once __DIR__ . '/../config/db.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($name === '' || $email === '' || $phone === '' || $password === '') {
        $message = "⚠️ Please fill all fields.";
    } else {

        $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE email = ?");
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);

        if (mysqli_stmt_num_rows($stmt) > 0) {
            $message = "❌ Email already registered.";
            mysqli_stmt_close($stmt);
        } else {
            mysqli_stmt_close($stmt);

            $hash = password_hash($password, PASSWORD_DEFAULT);

            // INSERT INTO USERS TABLE
            $stmt = mysqli_prepare($conn,
                "INSERT INTO users (name, email, phone, password, role, created_at) 
                 VALUES (?, ?, ?, ?, 'customer', NOW())"
            );
            mysqli_stmt_bind_param($stmt, 'ssss', $name, $email, $phone, $hash);

            if (mysqli_stmt_execute($stmt)) {

                mysqli_stmt_close($stmt);

                // ⭐ INSERT INTO CUSTOMER TABLE (for admin view)
                $stmt2 = mysqli_prepare($conn,
                    "INSERT INTO customer (name, email, phone, created_at) 
                     VALUES (?, ?, ?, NOW())"
                );
                mysqli_stmt_bind_param($stmt2, 'sss', $name, $email, $phone);
                mysqli_stmt_execute($stmt2);
                mysqli_stmt_close($stmt2);

                $message = "✅ Registration successful! Please login.";
            } else {
                $message = "❌ Registration failed. Try again.";
                mysqli_stmt_close($stmt);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Create Account | Restaurant System</title>

<style>
    * {
        margin: 0;
        padding: 0;
        font-family: 'Poppins', sans-serif;
        box-sizing: border-box;
    }

    body {
        background: #f1f1f1;
        height: 100vh;
        overflow: hidden;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        width: 850px;
        height: 520px;
        background: #fff;
        border-radius: 28px;
        overflow: hidden;
        display: flex;
        box-shadow: 0 12px 25px rgba(0,0,0,0.18);
    }

    .left {
        width: 50%;
        padding: 45px;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .left h1 {
        color: #b71c1c;
        font-size: 26px;
        margin-bottom: 5px;
        font-weight: 700;
    }

    .left p {
        color: #777;
        font-size: 14px;
        margin-bottom: 20px;
    }

    .message {
        background: #ffecec;
        color: #b71c1c;
        padding: 10px;
        margin-bottom: 15px;
        border-radius: 8px;
        font-size: 14px;
        text-align: center;
    }

    input {
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border-radius: 12px;
        border: 1px solid #ccc;
        font-size: 15px;
    }

    input:focus {
        border-color: #b71c1c;
        outline: none;
        box-shadow: 0px 0px 5px rgba(183,28,28,0.4);
    }

    .btn {
        width: 100%;
        padding: 12px;
        background: #b71c1c;
        border: none;
        border-radius: 12px;
        color: white;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        margin-top: 5px;
        transition: .2s;
    }

    .btn:hover {
        background: #8d1414;
    }

    .login-link {
        margin-top: 12px;
        font-size: 14px;
    }

    .login-link a {
        color: #b71c1c;
        font-weight: 600;
        text-decoration: none;
    }

    .right {
        width: 50%;
        background: url('../assets/images/menu/food-bg.jpg') center no-repeat;
        background-size: cover;
    }

    .top-header {
        background: #b71c1c;
        height: 70px;
        width: 100%;
        color: white;
        font-size: 20px;
        font-weight: 600;
        padding-left: 30px;
        display: flex;
        align-items: center;
        letter-spacing: 0.4px;
        position: fixed;
        top: 0;
        left: 0;
    }
</style>
</head>

<body>

<div class="top-header">🍽 Restaurant Management System</div>

<div class="container">

    <div class="left">
        <h1>Create Account</h1>
        <p>Register to continue</p>

        <?php if ($message): ?>
            <div class="message"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="text" name="phone" placeholder="Phone Number" required>
            <input type="password" name="password" placeholder="Create Password" required>
            <button type="submit" class="btn">REGISTER</button>
        </form>

        <div class="login-link">
            Already have an account? <a href="/RESTAURANT_MS/login.php">Login</a>
        </div>
    </div>

    <div class="right"></div>

</div>

</body>
</html>