<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Check Customer Login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'customer') {
    header("Location: ../login.php");
    exit;
}

$name = $_SESSION['name'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Customer Home | Restaurant</title>
<style>
body {
  font-family: 'Segoe UI', sans-serif;
  margin: 0;
  background: #fff5f5; /* light red tone */
  color: #333;
}

/* 🔴 Navbar */
.navbar {
  background: #b71c1c;
  color: white;
  padding: 12px 25px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.navbar h1 {
  font-size: 20px;
  margin: 0;
}
.navbar a {
  background: white;
  color: #b71c1c;
  padding: 8px 14px;
  border-radius: 6px;
  text-decoration: none;
  font-weight: 500;
}
.navbar a:hover {
  background: #b71c1c;
  color: white;
}

/* 🔴 Sidebar */
.sidebar {
  width: 230px;
  background: #fff;
  border-right: 1px solid #f2c5c5;
  height: 100vh;
  position: fixed;
  top: 50px;
  left: 0;
  padding-top: 20px;
}
.sidebar a {
  display: block;
  color: #333;
  padding: 12px 22px;
  text-decoration: none;
  border-left: 4px solid transparent;
  transition: 0.3s;
}
.sidebar a:hover,
.sidebar .active {
  background: #ffeaea;
  border-left: 4px solid #b71c1c;
}

/* 🩶 Main Section */
.main {
  margin-left: 250px;
  padding: 80px;
  text-align: center;
}
h2 {
  color: #b71c1c;
  font-size: 26px;
  margin-bottom: 10px;
}
p {
  color: #555;
  font-size: 18px;
}

footer {
  text-align: center;
  margin-top: 150px;
  color: #777;
  font-size: 14px;
}
</style>
</head>
<body>

<!-- 🔴 Navbar -->
<div class="navbar">
  <h1>🍽 Restaurant — Customer</h1>
  <a href="../logout.php">Logout</a>
</div>

<!-- 🔴 Sidebar -->
<div class="sidebar">
  <a href="home.php" class="active">🏠 Home</a>
  <a href="place_order.php">🍴 Place Order</a>
  <a href="my_orders.php">📦 My Orders</a>
  <a href="bill.php">🧾 My Bill</a>
  <a href="feedback.php">⭐ Feedback</a>
  <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- 🩶 Main -->
<div class="main">
  <h2>👋 Welcome, <?= htmlspecialchars($name) ?>!</h2>
  <p>We’re happy to serve you. Use the menu on the left to explore your options.</p>

  <footer>© <?= date('Y') ?> Restaurant Management System | Customer Dashboard</footer>
</div>

</body>
</html>