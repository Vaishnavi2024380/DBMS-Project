<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Check login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Validate ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: orders.php");
    exit;
}

$order_id = intval($_GET['id']);

// Fetch order details
$order_q = mysqli_query($conn, "SELECT * FROM orders WHERE id = $order_id LIMIT 1");
$order = mysqli_fetch_assoc($order_q);

// Fetch items
$items_q = mysqli_query($conn, "SELECT * FROM order_items WHERE order_id = $order_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Order Details | Admin Panel</title>

<style>
body {
    margin: 0;
    font-family: "Poppins", sans-serif;
    background: #f6fbf6;
}

/* HEADER */
.header {
    background: #1b5e20;
    padding: 15px 25px;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    top: 0; left: 0; right: 0;
    z-index: 1000;
}
.header h1 { margin: 0; font-size: 20px; }
.header a {
    background: white;
    color: #1b5e20;
    padding: 8px 14px;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
}
.header a:hover { background: #2e7d32; color: white; }

/* SIDEBAR */
.sidebar {
    width: 230px;
    background: white;
    height: 100vh;
    position: fixed;
    top: 60px;
    left: 0;
    border-right: 1px solid #ddd;
    padding-top: 10px;
}
.sidebar a {
    display: block;
    padding: 12px 25px;
    color: #333;
    text-decoration: none;
    border-left: 4px solid transparent;
}
.sidebar a:hover,
.sidebar .active {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

/* MAIN CONTENT */
.main {
    margin-left: 250px;
    padding: 100px 40px 40px;
}

.container {
    background: white;
    padding: 25px;
    border-radius: 10px;
    max-width: 900px;
    margin: auto;
    box-shadow: 0 3px 12px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
    color: #1b5e20;
    margin-bottom: 20px;
}

.details {
    display: grid;
    grid-template-columns: repeat(2,1fr);
    gap: 15px 40px;
    font-size: 15px;
}

.table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}
.table th {
    background: #1b5e20;
    color: white;
    padding: 10px;
}
.table td {
    border: 1px solid #e8eee8;
    padding: 10px;
    text-align: center;
}

/* BACK BUTTON */
.back-btn {
    display: block;
    margin-top: 20px;
    font-size: 15px;
    color: #1b5e20;
    text-decoration: none;
    font-weight: 500;
}
.back-btn:hover { color: #145317; }

/* Mobile */
@media (max-width: 700px) {
    .details { grid-template-columns: 1fr; }
}
</style>

</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>🍽 Admin — Order Details</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php">🍴 Manage Menu</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN -->
<div class="main">
<div class="container">

    <h2>Order Details</h2>

    <?php if (!$order): ?>
        <p style="text-align:center; color:#c62828;">❌ Order not found.</p>
        <a class="back-btn" href="orders.php">← Back to Orders</a>
    <?php exit; endif; ?>

    <div class="details">
        <div><b>Order ID:</b> <?= $order['id'] ?></div>
        <div><b>Customer:</b> <?= htmlspecialchars($order['customer_name']) ?></div>
        <div><b>Table No:</b> <?= $order['table_no'] ?: "N/A" ?></div>
        <div><b>Status:</b> <?= htmlspecialchars($order['status']) ?></div>
        <div><b>Total Items:</b> <?= $order['total_items'] ?></div>
        <div><b>Total Price:</b> ₹<?= $order['total_price'] ?></div>
        <div><b>Order Date:</b> <?= $order['order_date'] ?></div>
    </div>

    <h3 style="margin-top:25px; color:#1b5e20;">Ordered Items</h3>

    <table class="table">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Qty</th>
                <th>Price (₹)</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($items_q) > 0): ?>
                <?php while($item = mysqli_fetch_assoc($items_q)): ?>
                <tr>
                    <td><?= htmlspecialchars($item['item_name']) ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td><?= $item['price'] ?></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="3">No items found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- BACK BUTTON -->
    <a href="orders.php" class="back-btn">← Back to Orders</a>

</div>
</div>

</body>
</html>