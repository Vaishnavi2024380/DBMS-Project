<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Check Admin Login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$message = "";

// ✅ Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 1️⃣ Reset all items first
    mysqli_query($conn, "UPDATE menu_items SET today_special = 0, special_price = NULL");

    // 2️⃣ Apply specials from form
    if (!empty($_POST['special_items']) && is_array($_POST['special_items'])) {

        foreach ($_POST['special_items'] as $item_id) {
            $item_id = intval($item_id);

            // Get entered special price
            $raw_price = trim($_POST['special_price'][$item_id] ?? '');

            if ($raw_price === '' || floatval($raw_price) <= 0) {
                // If no price entered, only mark as special
                $query = "UPDATE menu_items SET today_special = 1, special_price = NULL WHERE id = $item_id";
            } else {
                // If valid price entered
                $special_price = floatval($raw_price);
                $query = "UPDATE menu_items SET today_special = 1, special_price = $special_price WHERE id = $item_id";
            }

            mysqli_query($conn, $query);
        }
    }

    $message = "✅ Today's Special menu updated successfully!";
}

// ✅ Fetch items with category + image
$items = mysqli_query($conn, "
    SELECT m.id, m.category, m.price, m.special_price, m.today_special, m.image, 
           c.name AS category_name
    FROM menu_items m
    LEFT JOIN categories c ON m.category_id = c.id
    ORDER BY c.name ASC, m.category ASC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>⭐ Today's Special Menu | Admin Panel</title>

<style>
/* GLOBAL */
body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:#f4f6f9;
    color:#333;
}

/* HEADER */
.header{
    background:#1b5e20;
    color:white;
    padding:15px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:fixed;
    top:0;left:0;right:0;
    z-index:1000;
}
.header h1{
    margin:0;
    font-size:20px;
}
.header a{
    background:white;
    color:#1b5e20;
    padding:8px 14px;
    border-radius:6px;
    text-decoration:none;
    font-weight:bold;
}
.header a:hover{
    background:#2e7d32;
    color:white;
}

/* SIDEBAR */
.sidebar{
    width:230px;
    background:white;
    border-right:1px solid #dcdcdc;
    height:100vh;
    position:fixed;
    top:60px;
    left:0;
    padding-top:10px;
}
.sidebar a{
    display:block;
    padding:12px 25px;
    color:#333;
    text-decoration:none;
    border-left:4px solid transparent;
    transition:0.3s;
}
.sidebar a:hover,
.sidebar .active{
    background:#e9f5ef;
    border-left:4px solid #1b5e20;
}

/* MAIN */
.main{
    margin-left:250px;
    padding:80px 40px;
}
.container{
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 4px 12px rgba(0,0,0,0.1);
}

h2{
    margin:0 0 10px 0;
    color:#1b5e20;
}

/* TOP ROW WITH BUTTON */
.top-row{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:15px;
    gap:15px;
}
.top-row span{
    font-size:14px;
    color:#555;
}
.btn-save{
    background: none;
    border: none;
    color: #145a32;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    padding: 6px 0;
}

.btn-save:hover{
    color: #0e4627;
    text-decoration: underline;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
    margin-top:10px;
}
th,td{
    border:1px solid #eee;
    padding:10px;
    text-align:center;
    font-size:14px;
}
th{
    background:#eaf6ea;
    color:#1b5e20;
}
tr:hover{
    background:#f8faf8;
}

/* IMAGE */
.thumb{
    width:80px;
    height:60px;
    object-fit:cover;
    border-radius:6px;
    border:1px solid #ccc;
}

/* INPUTS */
input[type="number"]{
    width:80px;
    padding:5px;
    border:1px solid #ccc;
    border-radius:6px;
}

/* MESSAGE */
.message{
    background:#eaf6ea;
    color:#1b5e20;
    padding:8px 12px;
    border-radius:6px;
    margin-bottom:10px;
    font-size:14px;
    text-align:center;
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>⭐ Admin — Today's Special Menu</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php">🍕 Manage Menu</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php" class="active">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">
<div class="container">

    <h2>Manage Today's Special Menu</h2>

    <?php if($message): ?>
        <div class="message"><?= $message ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="top-row">
            <span>✅ Tick items you want to show in <b>Today's Special</b> and (optional) set an offer price.</span>
            <button type="submit" class="btn-save"> Save Special Menu</button>
        </div>

        <table>
            <tr>
                <th>Special?</th>
                <th>Image</th>
                <th>Item</th>
                <th>Category</th>
                <th>Original Price (₹)</th>
                <th>Special Price (₹)</th>
            </tr>

            <?php if ($items && mysqli_num_rows($items) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($items)): ?>
                    <?php
                        $imgPath = !empty($row['image'])
                            ? "../assets/images/menu/" . htmlspecialchars($row['image'])
                            : "../assets/images/menu/default-food.jpg";
                    ?>
                    <tr>
                        <td>
                            <input type="checkbox"
                                   name="special_items[]"
                                   value="<?= $row['id'] ?>"
                                   <?= $row['today_special'] ? 'checked' : '' ?>>
                        </td>
                        <td>
                            <img src="<?= $imgPath ?>" alt="Item Image" class="thumb">
                        </td>
                        <td><?= htmlspecialchars($row['category']) ?></td>
                        <td><?= htmlspecialchars($row['category_name']) ?></td>
                        <td>₹<?= number_format($row['price'], 2) ?></td>
                        <td>
                            <input type="number"
                                   name="special_price[<?= $row['id'] ?>]"
                                   min="1"
                                   step="0.01"
                                   value="<?= $row['special_price'] !== null ? htmlspecialchars($row['special_price']) : '' ?>">
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6">No menu items found.</td></tr>
            <?php endif; ?>
        </table>
    </form>

</div>
</div>

</body>
</html>