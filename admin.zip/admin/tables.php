<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Admin login check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// ------------ ADD TABLE ------------
if (isset($_POST['add_table'])) {
    $no = intval($_POST['table_no']);
    $cap = intval($_POST['capacity']);

    $conn->query("INSERT INTO tables (table_no, capacity, status) VALUES ($no, $cap, 'Available')");
    header("Location: tables.php");
    exit;
}

// ------------ EDIT TABLE ------------
if (isset($_POST['edit_table'])) {
    $id = intval($_POST['id']);
    $cap = intval($_POST['capacity']);  // Only capacity is editable

    $conn->query("UPDATE tables SET capacity=$cap WHERE id=$id");
    header("Location: tables.php");
    exit;
}

// ------------ DELETE ------------
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM tables WHERE id=$id");
    header("Location: tables.php");
    exit;
}

// Fetch tables
$result = $conn->query("SELECT * FROM tables ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Table Management | Admin Panel</title>

<style>
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    background: #f6fbf6;
}

/* HEADER */
.header {
    background: #1b5e20;
    color: white;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    left: 0; right: 0; top: 0;
    z-index: 1000;
}
.header h1 {
    margin: 0;
    font-size: 20px;
}
.header a {
    background: white;
    color: #1b5e20;
    padding: 8px 14px;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
}
.header a:hover { background: #2e7d32; color: white; }

/* ADD BUTTON */
.add-btn {
    padding: 8px 16px;
    background: #1b5e20;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    float: right;
    margin-bottom: 15px;
    font-size: 14px;
}
.add-btn:hover { background: #2e7d32; }

/* SIDEBAR */
.sidebar {
    width: 230px;
    background: white;
    height: 100vh;
    position: fixed;
    top: 60px;
    left: 0;
    border-right: 1px solid #ddd;
    padding-top: 10px;
}
.sidebar a {
    display: block;
    padding: 12px 25px;
    text-decoration: none;
    color: #333;
    border-left: 4px solid transparent;
}
.sidebar a:hover,
.sidebar .active {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

/* MAIN */
.main {
    margin-left: 250px;
    padding: 100px 40px 40px;
}
.container {
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}
h2 { color: #1b5e20; text-align:center; }

/* TABLE */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
th, td {
    padding: 10px;
    border: 1px solid #e2e2e2;
    text-align: center;
}
th { background: #eaf6ea; color: #1b5e20; }

.status-available { color: green; font-weight: bold; }
.status-reserved { color: #f39c12; font-weight: bold; }

/* ACTION BUTTONS */
.btn-edit {
    background: #2e7d32;
    padding: 5px 10px;
    color: white;
    border-radius: 6px;
    text-decoration: none;
    font-size: 12px;
}
.btn-edit:hover { background: #1b5e20; }

.btn-delete {
    background: #c62828;
    padding: 5px 10px;
    color: white;
    border-radius: 6px;
    text-decoration: none;
    font-size: 12px;
}
.btn-delete:hover { background: #8e0000; }

/* FOOTER */
footer {
    text-align: center;
    margin-top: 30px;
    font-size: 14px;
    color: #555;
}

/* POPUPS */
.popup-bg {
    position: fixed;
    top:0; left:0; right:0; bottom:0;
    background: rgba(0,0,0,0.4);
    display: none;
    justify-content: center;
    align-items: center;
}
.popup {
    background: white;
    padding: 25px;
    width: 350px;
    border-radius: 10px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.3);
}
.popup h3 { text-align:center; color:#1b5e20; }
.popup input {
    width:100%; padding:10px;
    margin-top:10px; margin-bottom:15px;
    border-radius:6px; border:1px solid #ccc;
}
.popup button {
    width:100%; padding:10px;
    background:#1b5e20; color:white;
    border:none; border-radius:6px;
    font-size:15px; cursor:pointer;
}
.popup button:hover { background:#2e7d32; }
</style>

</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>🪑 Admin — Table Management</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php">🍴 Manage Menu</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php" class="active">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN -->
<div class="main">
<div class="container">

    <a class="add-btn" onclick="openAdd()">+ Add Table</a>

    <h2>Table Availability</h2>

    <table>
        <thead>
            <tr>
                <th>Table Number</th>
                <th>Capacity</th>
                <th>Status</th>
                <th>Reserved By</th>
                <th>Actions</th>
            </tr>
        </thead>

        <tbody>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['table_no'] ?></td>
            <td><?= $row['capacity'] ?></td>
            <td class="status-<?= strtolower($row['status']) ?>"><?= $row['status'] ?></td>
            <td><?= $row['reserved_by'] ?: '-' ?></td>

            <td>
                <a class="btn-edit" onclick="openEdit(<?= $row['id'] ?>,'<?= $row['table_no'] ?>','<?= $row['capacity'] ?>')">Edit</a>
                <a class="btn-delete" href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this table?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
        </tbody>
    </table>

    <footer>
        © <?= date('Y') ?> Restaurant Management System | Table Management
    </footer>

</div>
</div>

<!-- ADD POPUP -->
<div class="popup-bg" id="addPopup">
    <div class="popup">
        <h3>Add Table</h3>
        <form method="POST">
            <label>Table Number</label>
            <input type="number" name="table_no" required>

            <label>Capacity</label>
            <input type="number" name="capacity" required>

            <button name="add_table">Add Table</button>
        </form>
    </div>
</div>

<!-- EDIT POPUP -->
<div class="popup-bg" id="editPopup">
    <div class="popup">
        <h3>Edit Table</h3>
        <form method="POST">
            <input type="hidden" name="id" id="edit_id">

            <label>Table Number</label>
            <input type="number" id="edit_no" name="table_no" readonly>

            <label>Capacity</label>
            <input type="number" id="edit_cap" name="capacity" required>

            <button name="edit_table">Update</button>
        </form>
    </div>
</div>

<script>
function openAdd() {
    document.getElementById("addPopup").style.display="flex";
}
function openEdit(id,no,cap) {
    document.getElementById("edit_id").value = id;
    document.getElementById("edit_no").value = no;
    document.getElementById("edit_cap").value = cap;
    document.getElementById("editPopup").style.display="flex";
}

// Close popup on outside click
window.onclick = function(e){
    if(e.target.classList.contains('popup-bg')){
        e.target.style.display="none";
    }
}
</script>

</body>
</html>