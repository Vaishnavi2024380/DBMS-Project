<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Check Admin Login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);

    if ($name === '') {
        $msg = "⚠️ Category name is required.";
    } else {
        $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->bind_param('s', $name);

        if ($stmt->execute()) {
            echo "<script>alert('✅ Category added successfully!'); window.location.href='manage_menu.php';</script>";
            exit;
        } else {
            $msg = "❌ Error: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Category | Admin Panel</title>

<style>
/* GLOBAL */
body {
    font-family: 'Poppins', sans-serif;
    background: #f4f6f9;
    margin: 0;
}

/* HEADER */
.header {
    background: #1b5e20;
    padding: 15px 25px;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    top: 0; left: 0; right: 0;
    z-index: 1000;
}
.header h1 { margin: 0; font-size: 20px; }
.header a {
    background: white;
    color: #1b5e20;
    padding: 8px 14px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
}
.header a:hover { background: #2e7d32; color: white; }

/* SIDEBAR */
.sidebar {
    width: 230px;
    background: white;
    height: 100vh;
    position: fixed;
    top: 60px;
    left: 0;
    border-right: 1px solid #dcdcdc;
    padding-top: 10px;
}
.sidebar a {
    display: block;
    padding: 12px 25px;
    text-decoration: none;
    color: #333;
    border-left: 4px solid transparent;
    transition: 0.3s;
}
.sidebar a:hover,
.sidebar .active {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

/* MAIN AREA */
.main {
    margin-left: 250px;
    padding: 90px 40px;
}

.container {
    max-width: 600px;
    margin: auto;
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
    color: #1b5e20;
}

/* FORM */
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

input[type="text"] {
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 16px;
}

button {
    padding: 12px;
    background: #1b5e20;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
}
button:hover { background: #145a18; }

.message {
    text-align: center;
    color: red;
    font-weight: bold;
    margin-bottom: 10px;
}

/* BACK LINK */
.back {
    display: block;
    text-align: center;
    margin-top: 15px;
    font-weight: bold;
    color: #1b5e20;
    text-decoration: none;
}
.back:hover { color: #2e7d32; }
</style>

</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>➕ Add New Category</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php" class="active">🍕 Manage Menu</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN -->
<div class="main">
<div class="container">

    <h2>Add New Category</h2>

    <?php if ($msg): ?>
        <div class="message"><?= $msg ?></div>
    <?php endif; ?>

    <form method="post">
        <label><b>Category Name:</b></label>
        <input type="text" name="name" placeholder="Enter category name..." required>

        <button type="submit">➕ Add Category</button>
    </form>

    <a href="manage_menu.php" class="back">← Back to Manage Menu</a>

</div>
</div>

</body>
</html>