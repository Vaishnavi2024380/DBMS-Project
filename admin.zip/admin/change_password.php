<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Check Admin Login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = $_POST['current_password'];
    $new = $_POST['new_password'];
    $confirm = $_POST['confirm_password'];
    $user_id = $_SESSION['user_id'];

    // Fetch current password
    $res = mysqli_query($conn, "SELECT password FROM users WHERE id=$user_id");
    $row = mysqli_fetch_assoc($res);

    if (!password_verify($current, $row['password'])) {
        $msg = "❌ Current password is incorrect.";
    } elseif ($new !== $confirm) {
        $msg = "❌ New passwords do not match.";
    } else {
        $hashed = password_hash($new, PASSWORD_DEFAULT);
        mysqli_query($conn, "UPDATE users SET password='$hashed' WHERE id=$user_id");
        $msg = "✅ Password updated successfully!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>🔑 Change Password | Admin Panel</title>

<style>
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    background: #f4f6f9;
}

/* HEADER */
.header {
    background: #1b5e20;
    padding: 15px 25px;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    left: 0; right: 0; top: 0;
    z-index: 1000;
}
.header h1 { margin: 0; font-size: 20px; }
.header a {
    background: white;
    color: #1b5e20;
    padding: 8px 14px;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
}
.header a:hover { background:#2e7d32; color:white; }

/* SIDEBAR */
.sidebar {
    width: 230px;
    background: white;
    height: 100vh;
    position: fixed;
    top: 60px;
    left: 0;
    border-right: 1px solid #ddd;
    padding-top: 10px;
}
.sidebar a {
    display: block;
    padding: 12px 25px;
    text-decoration: none;
    color: #333;
    border-left: 4px solid transparent;
}
.sidebar a:hover,
.sidebar .active {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

/* MAIN */
.main {
    margin-left: 250px;
    padding: 120px 40px;
    display: flex;
    justify-content: center;
}

.container {
    width: 420px;
    background: white;
    padding: 35px;
    border-radius: 12px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.1);
    text-align: center;
}

.container h2 {
    color: #1b5e20;
    margin-bottom: 20px;
}

/* INPUTS */
.input-group {
    position: relative;
    margin-bottom: 20px;
}

.input-group input {
    width: 100%;
    padding: 11px 38px 11px 12px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 15px;
    box-sizing: border-box;
}

.eye-toggle {
    position: absolute;
    right: 10px;
    top: 50%;
    transform: translateY(-50%);
    font-size: 18px;
    cursor: pointer;
    color: #555;
}

button {
    background: #1b5e20;
    padding: 12px;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    width: 100%;
    cursor: pointer;
}
button:hover {
    background: #145317;
}

.back-btn {
    margin-top: 18px;
    display: inline-block;
    padding: 8px 16px;
    border: 1px solid #333;
    border-radius: 6px;
    color: #333;
    text-decoration: none;
}
.back-btn:hover {
    background: #ddd;
}

.message { color: green; margin-top: 10px; font-weight: 600; }
.error { color: red; }
</style>

<script>
function togglePassword(id, el) {
    let input = document.getElementById(id);
    if (input.type === "password") {
        input.type = "text";
        el.textContent = "🙈";
    } else {
        input.type = "password";
        el.textContent = "👁️";
    }
}
</script>

</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>🔑 Change Password — Admin</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php">🍕 Manage Menu</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php" class="active">🔑 Change Password</a>
</div>

<!-- CONTENT -->
<div class="main">
    <div class="container">

        <h2>Change Password</h2>

        <form method="POST">

            <div class="input-group">
                <input type="password" name="current_password" id="p1" placeholder="Current Password" required>
                <span class="eye-toggle" onclick="togglePassword('p1', this)">👁️</span>
            </div>

            <div class="input-group">
                <input type="password" name="new_password" id="p2" placeholder="New Password" required>
                <span class="eye-toggle" onclick="togglePassword('p2', this)">👁️</span>
            </div>

            <div class="input-group">
                <input type="password" name="confirm_password" id="p3" placeholder="Confirm New Password" required>
                <span class="eye-toggle" onclick="togglePassword('p3', this)">👁️</span>
            </div>

            <button type="submit">Update Password</button>
        </form>

        <?php if($msg): ?>
            <p class="<?= strpos($msg, '❌') !== false ? 'error' : 'message' ?>"><?= $msg ?></p>
        <?php endif; ?>

        <a href="dashboard.php" class="back-btn">← Back</a>

    </div>
</div>

</body>
</html>