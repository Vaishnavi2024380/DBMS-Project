<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// 🔐 Admin check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    echo "Invalid request!";
    exit;
}

$order_id = intval($_GET['id']);

// Fetch order details
$order_q = mysqli_query($conn, "SELECT * FROM orders WHERE id=$order_id");
$order = mysqli_fetch_assoc($order_q);

// Fetch ordered items
$items_q = mysqli_query($conn, "SELECT * FROM order_items WHERE order_id=$order_id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Customer Bill | Admin Panel</title>

<style>
body {
  font-family: 'Poppins', sans-serif;
  margin: 0;
  background: #f6fbf6;
}

/* HEADER */
.header {
  background: #1b5e20;
  padding: 15px 25px;
  color: #fff;
  display: flex;
  justify-content: space-between;
  position: fixed;
  top: 0; left: 0; right: 0;
  z-index: 1000;
}
.header h3 { margin: 0; font-size: 20px; }
.header a {
  background: white;
  color: #1b5e20;
  padding: 8px 14px;
  border-radius: 6px;
  text-decoration: none;
}

/* SIDEBAR */
.sidebar {
  width: 230px;
  background: #fff;
  border-right: 1px solid #dcdcdc;
  height: 100vh;
  position: fixed;
  top: 60px; left: 0;
  padding-top: 20px;
}
.sidebar a {
  display: block;
  padding: 12px 25px;
  text-decoration: none;
  color: #1b5e20;
  border-left: 4px solid transparent;
}
.sidebar .active, .sidebar a:hover {
  background: #e9f5ef;
  border-left: 4px solid #1b5e20;
}

/* MAIN */
.main {
  margin-left: 250px;
  padding: 100px 40px;
}

.bill-card {
  background: white;
  padding: 25px;
  max-width: 750px;
  margin: auto;
  border-radius: 10px;
  box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

.bill-header {
  display: flex;
  justify-content: space-between;
  border-bottom: 2px dashed #ddd;
  padding-bottom: 10px;
  margin-bottom: 20px;
}

.bill-header h3 {
  margin: 0;
  color: #1b5e20;
}

/* TABLE – fixed alignment */
table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
  margin-top: 10px;
}
thead th {
  background: #e8f6e8;
  color: #1b5e20;
  padding: 10px;
  text-align: center;
}
tbody td {
  border-bottom: 1px solid #eee;
  padding: 8px;
  text-align: center;
  word-wrap: break-word;
}

.total {
  text-align: right;
  margin-top: 10px;
  font-size: 18px;
  font-weight: bold;
  color: #1b5e20;
}

.status-badge {
  background: #1b5e20;
  color: white;
  padding: 4px 12px;
  border-radius: 20px;
}

/* BUTTONS */
.action-buttons {
  margin-top: 25px;
  text-align: center;
}

.print-btn {
  background: #1b5e20;
  color: white;
  padding: 10px 18px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 15px;
  margin-right: 8px;
}
.print-btn:hover { background: #2e7d32; }

.back-btn {
  background: #1976d2;
  color: white;
  padding: 10px 20px;
  border-radius: 6px;
  text-decoration: none;
  font-size: 15px;
}
.back-btn:hover {
  background: #0d47a1;
}
</style>

<script>
function printBill() {
    var divContent = document.getElementById("printArea").innerHTML;
    var w = window.open('', '', 'width=800,height=600');
    w.document.write('<html><head><title>Print Bill</title>');
    w.document.write('<style>body{font-family:Poppins,sans-serif;padding:20px;} table{width:100%;border-collapse:collapse;table-layout:fixed;} thead th{background:#e8f6e8;color:#1b5e20;padding:8px;text-align:center;} tbody td{border-bottom:1px solid #eee;padding:8px;text-align:center;}</style>');
    w.document.write('</head><body>');
    w.document.write(divContent);
    w.document.write('</body></html>');
    w.document.close();
    w.print();
}
</script>

</head>
<body>

<!-- HEADER -->
<div class="header">
  <h3>🍽️ Restaurant Management — Admin</h3>
  <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
  <a href="dashboard.php">🏠 Dashboard</a>
  <a href="orders.php" class="active">📦 Orders</a>
  <a href="manage_menu.php">🍕 Manage Menu</a>
  <a href="staff.php">👨‍🍳 Staff</a>
  <a href="customers.php">👥 Customers</a>
  <a href="tables.php">🪑 Tables</a>
  <a href="todays_special.php">⭐ Today's Special</a>
  <a href="feedback.php">💬 Feedback</a>
  <a href="reports.php">📊 Reports</a>
  <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN -->
<div class="main">

<div class="bill-card" id="printArea">

    <div class="bill-header">
        <h3>Restaurant Customer Bill</h3>
        <span><b>Order ID:</b> #<?= $order['id'] ?></span>
    </div>

    <p>
      <b>Customer:</b> <?= $order['customer_name'] ?><br>
      <b>Date:</b> <?= $order['order_date'] ?><br>
      <b>Table No:</b> <?= $order['table_no'] ?><br>
    </p>

    <table>
        <thead>
          <tr>
              <th>Item Name</th>
              <th>Qty</th>
              <th>Price (₹)</th>
          </tr>
        </thead>
        <tbody>
        <?php while ($i = mysqli_fetch_assoc($items_q)): ?>
          <tr>
              <td><?= htmlspecialchars($i['item_name']) ?></td>
              <td><?= $i['quantity'] ?></td>
              <td><?= $i['price'] ?></td>
          </tr>
        <?php endwhile; ?>
        </tbody>
    </table>

    <div class="total">
        Total Amount: ₹<?= number_format($order['total_price'], 2) ?>
    </div>

    <p><b>Status:</b>
        <span class="status-badge"><?= $order['status'] ?></span>
    </p>
</div>

<!-- BOTTOM BUTTONS -->
<div class="action-buttons">
    <button class="print-btn" onclick="printBill()">🖨 Print Bill</button>
    <a href="orders.php" class="back-btn">← Back to Orders</a>
</div>

</div>

</body>
</html>