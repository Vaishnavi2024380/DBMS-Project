<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Check Admin Login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// ✅ Fetch Categories
$cats = [];
$res = $conn->query("SELECT id, name FROM categories ORDER BY name");
while ($r = $res->fetch_assoc()) $cats[] = $r;

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $category_id  = intval($_POST['category_id']);
    $item_name    = trim($_POST['name']);
    $price        = floatval($_POST['price']);
    $special_price = ($_POST['special_price'] !== "") ? floatval($_POST['special_price']) : NULL;
    $description  = trim($_POST['description']);
    $today_special = isset($_POST['today_special']) ? 1 : 0;

    $imageName = null;

    // ✅ IMAGE UPLOAD
    if (!empty($_FILES['image']['name'])) {
        $allowed = ['jpg','jpeg','png','webp'];
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $tmp = $_FILES['image']['tmp_name'];

        if (!in_array($ext, $allowed)) {
            $msg = "⚠️ Only JPG, JPEG, PNG, WEBP allowed.";
        } else {
            $safeName = time() . "_" . preg_replace('/[^A-Za-z0-9\-.]/','',$_FILES['image']['name']);
            $path = __DIR__ . '/../assets/images/menu/' . $safeName;
            if (move_uploaded_file($tmp, $path)) {
                $imageName = $safeName;
            }
        }
    }

    if ($msg === '') {
        $stmt = $conn->prepare("
            INSERT INTO menu_items 
            (category_id, category, price, special_price, description, image, today_special)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "isddssi",
            $category_id,
            $item_name,
            $price,
            $special_price,
            $description,
            $imageName,
            $today_special
        );

        if ($stmt->execute()) {
            echo "<script>alert('✅ Menu Item added successfully!'); window.location.href='manage_menu.php';</script>";
            exit;
        } else {
            $msg = "❌ Database Error: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Menu Item | Admin Panel</title>

<style>
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    background: #f4f6f9;
}

/* HEADER */
.header {
    background: #1b5e20;
    padding: 15px 25px;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    left: 0; right: 0; top: 0;
    z-index: 1000;
}
.header h1 { margin: 0; font-size: 20px; }
.header a {
    background: white;
    color: #1b5e20;
    padding: 8px 14px;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
}
.header a:hover { background:#2e7d32; color:white; }

/* SIDEBAR */
.sidebar {
    width: 230px;
    background: white;
    height: 100vh;
    position: fixed;
    top: 60px;
    left: 0;
    border-right: 1px solid #ddd;
    padding-top: 10px;
}
.sidebar a {
    display: block;
    padding: 12px 25px;
    text-decoration: none;
    color: #333;
    border-left: 4px solid transparent;
}
.sidebar a:hover,
.sidebar .active {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

/* MAIN */
.main {
    margin-left: 250px;
    padding: 90px 40px 40px;
}

.container {
    max-width: 750px;
    margin: auto;
    background: white;
    border-radius: 12px;
    padding: 30px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.12);
}

h2 {
    text-align: center;
    color: #1b5e20;
}

/* FORM */
form {
    display: flex;
    flex-direction: column;
    gap: 18px;
}

label {
    font-weight: bold;
    color: #145a32;
}

input[type="text"],
input[type="number"],
textarea,
select {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 6px;
    width: 100%;
    font-size: 15px;
}

textarea { resize: vertical; height: 80px; }

button {
    background: #1b5e20;
    padding: 12px;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
}
button:hover { background: #114d19; }

.message {
    text-align: center;
    font-weight: bold;
    color: red;
}

/* BACK LINK */
.back {
    display: block;
    margin-top: 15px;
    text-align: center;
    font-weight: bold;
    color: #1b5e20;
    text-decoration: none;
}
.back:hover { color: #2e7d32; }
</style>

</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>🍕 Add Menu Item</h1>
    <a href="manage_menu.php">← Back</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php" class="active">🍴 Manage Menu</a>
    <a href="todays_special.php">⭐ Today's Special</a>
    <a href="customers.php">👥 Customers</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">
<div class="container">

    <h2>Add New Menu Item</h2>

    <?php if($msg): ?>
        <div class="message"><?= $msg ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">

        <label>Item Name:</label>
        <input type="text" name="name" required>

        <label>Select Category:</label>
        <select name="category_id" required>
            <option value="">-- Select Category --</option>
            <?php foreach ($cats as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
            <?php endforeach; ?>
        </select>

        <label>Price (₹):</label>
        <input type="number" name="price" step="0.01" required>

        <label>Special Price (Optional):</label>
        <input type="number" name="special_price" step="0.01">

        <label>Description:</label>
        <textarea name="description"></textarea>

        <label>Upload Image:</label>
        <input type="file" name="image" accept="image/*">

        <label>
            <input type="checkbox" name="today_special"> ⭐ Mark as Today's Special
        </label>

        <button type="submit">➕ Add Item</button>
    </form>

    <a href="manage_menu.php" class="back">← Back to Manage Menu</a>

</div>
</div>

</body>
</html>