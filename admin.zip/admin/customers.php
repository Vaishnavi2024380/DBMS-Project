<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Delete customer
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM customer WHERE id=$id");
    header("Location: customers.php");
    exit;
}

// Search
$search = "";
if (!empty($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    $query = "SELECT * FROM customer 
              WHERE name LIKE '%$search%' 
              OR email LIKE '%$search%' 
              OR phone LIKE '%$search%'
              ORDER BY created_at DESC";
} else {
    $query = "SELECT * FROM customer ORDER BY created_at DESC";
}

$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Registered Customers | Admin Panel</title>

<style>
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    background: #f6fbf6;
}

.header {
    background: #1b5e20;
    padding: 15px 25px;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    left: 0; right: 0; top: 0;
    z-index: 1000;
}

.sidebar {
    width: 230px;
    background: white;
    position: fixed;
    top: 60px;
    bottom: 0;
    left: 0;
    border-right: 1px solid #ddd;
    padding-top: 10px;
}

.sidebar a {
    display: block;
    padding: 12px 25px;
    text-decoration: none;
    color: #333;
}

.sidebar .active,
.sidebar a:hover {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

.main {
    margin-left: 250px;
    padding: 100px 40px 40px;
}

.search-box {
    text-align: right;
    margin-bottom: 15px;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    box-shadow: 0 3px 10px rgba(0,0,0,0.06);
}

th, td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: center;
}

.btn-delete {
    background: #d32f2f;
    padding: 6px 10px;
    color: white;
    text-decoration: none;
    border-radius: 6px;
}
</style>

<script>
function confirmDelete(id) {
    if (confirm("Are you sure you want to delete this customer?")) {
        window.location.href = "customers.php?delete=" + id;
    }
}
</script>

</head>
<body>

<div class="header">
    <h1>👥 Registered Customers</h1>
    <a href="../logout.php">Logout</a>
</div>

<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php">🍴 Manage Menu</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a class="active" href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<div class="main">

    <h2>Registered Customers</h2>

    <form method="get" class="search-box">
        <input type="text" name="search" placeholder="Search by name, email, phone"
               value="<?= htmlspecialchars($search) ?>">
        <button>Search</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Registered On</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['phone']) ?></td>
                <td><?= $row['created_at'] ?></td>
                <td>
                    <a class="btn-delete" href="javascript:void(0);" onclick="confirmDelete(<?= $row['id'] ?>)">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6">No customers found.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>

</div>

</body>
</html>