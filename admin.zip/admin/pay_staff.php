<?php
session_start();
require_once __DIR__ . '/../config/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Search and filter logic
$search = $_GET['search'] ?? '';
$role_filter = $_GET['role'] ?? 'All';

$query = "SELECT * FROM staff WHERE 1";
$params = [];
if (!empty($search)) {
    $query .= " AND (name LIKE ? OR email LIKE ?)";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}
if ($role_filter !== 'All') {
    $query .= " AND role = ?";
    $params[] = $role_filter;
}

$stmt = $conn->prepare($query);
if ($params) {
    $types = str_repeat("s", count($params));
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Staff | Restaurant Admin</title>
<style>
body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: #f4f6f8;
}
.sidebar {
    width: 230px;
    position: fixed;
    top: 0; left: 0;
    height: 100%;
    background: #2c3e50;
    color: #fff;
    padding-top: 20px;
}
.sidebar h2 { text-align: center; margin-bottom: 30px; }
.sidebar a {
    display: block;
    color: #fff;
    text-decoration: none;
    padding: 10px 20px;
    margin: 4px 10px;
    border-radius: 6px;
}
.sidebar a:hover { background: #34495e; }
.main {
    margin-left: 250px;
    padding: 20px;
}
.container {
    background: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}
h1 {
    text-align: center;
    color: #d35400;
    margin-bottom: 15px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}
table, th, td {
    border: 1px solid #ddd;
}
th {
    background: #d35400;
    color: white;
    padding: 10px;
}
td {
    text-align: center;
    padding: 8px;
}
.search-bar {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-bottom: 10px;
}
input, select {
    padding: 6px;
    border: 1px solid #ccc;
    border-radius: 5px;
}
button, .btn {
    background: #d35400;
    color: white;
    border: none;
    padding: 6px 10px;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none;
}
button:hover, .btn:hover {
    background: #b84300;
}
.small-btn {
    padding: 4px 8px;
    font-size: 12px;
}
.btn-green { background: #27ae60; }
.btn-blue { background: #3498db; }
.btn-red { background: #e74c3c; }
.btn-orange { background: #e67e22; }
.status-active {
    color: green;
    font-weight: bold;
}
.status-inactive {
    color: red;
    font-weight: bold;
}
footer {
    text-align: center;
    margin-top: 20px;
    color: #888;
    font-size: 13px;
}
</style>
</head>
<body>
<div class="sidebar">
    <h2>🍴 Admin Panel</h2>
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="manage_menu.php">🍕 Manage Menu</a>
    <a href="manage_staff.php" style="background:#d35400;">👨‍🍳 Manage Staff</a>
    <a href="view_orders.php">🛍️ Orders</a>
    <a href="view_feedback.php">💬 Feedback</a>
    <a href="../logout.php">🚪 Logout</a>
</div>

<div class="main">
    <div class="container">
        <h1>👨‍🍳 Manage Staff</h1>

        <form method="GET" class="search-bar">
            <input type="text" name="search" placeholder="Search name or email..." value="<?= htmlspecialchars($search) ?>">
            <select name="role">
                <option value="All">All Roles</option>
                <?php
                $roles = ['Manager', 'Chef', 'Waiter', 'Cashier', 'Cleaner'];
                foreach ($roles as $r) {
                    $selected = ($role_filter == $r) ? 'selected' : '';
                    echo "<option value='$r' $selected>$r</option>";
                }
                ?>
            </select>
            <button type="submit">🔍 Search</button>
            <a href="add_staff.php" class="btn btn-green">➕ Add Staff</a>
        </form>

        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Role</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Salary (₹)</th>
                <th>Hire Date</th>
                <th>Shift Time</th>
                <th>Status</th>
                <th>Payment</th>
                <th>Actions</th>
            </tr>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['role']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['phone']) ?></td>
                        <td><?= number_format($row['salary'], 2) ?></td>
                        <td><?= $row['hire_date'] ?></td>
                        <td><?= $row['shift_start'] && $row['shift_end'] ? $row['shift_start'] . ' - ' . $row['shift_end'] : 'N/A' ?></td>
                        <td>
                            <span class="<?= $row['status'] == 'Active' ? 'status-active' : 'status-inactive' ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td>
                            <?= $row['payment_status'] == 'Paid'
                                ? "<span style='color:green;font-weight:bold;'>Paid</span>"
                                : "<a href='pay_staff.php?id={$row['id']}' class='small-btn btn-orange'>Pay</a>"; ?>
                        </td>
                        <td>
                            <a href="edit_staff.php?id=<?= $row['id'] ?>" class="small-btn btn-blue">✏️</a>
                            <a href="delete_staff.php?id=<?= $row['id'] ?>" class="small-btn btn-red" onclick="return confirm('Delete this staff?');">🗑️</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="11">No staff found.</td></tr>
            <?php endif; ?>
        </table>

        <br>
        <a href="dashboard.php" class="btn btn-orange">⬅ Back to Dashboard</a>
    </div>

    <footer>
        © <?= date('Y') ?> Restaurant Management System | Admin Panel
    </footer>
</div>
</body>
</html>