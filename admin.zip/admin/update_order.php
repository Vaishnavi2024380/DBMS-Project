<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Check Admin Login
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// ✅ Get Order ID
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($order_id <= 0) {
    echo "Invalid Order ID.";
    exit;
}

// ✅ Fetch Order Details
$query = "SELECT * FROM orders WHERE id = $order_id";
$result = mysqli_query($conn, $query);
$order = mysqli_fetch_assoc($result);

if (!$order) {
    echo "Order not found.";
    exit;
}

// ✅ Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $status = $_POST['status'];
    $update_query = "UPDATE orders SET status = '$status' WHERE id = $order_id";

    if (mysqli_query($conn, $update_query)) {
        header("Location: orders.php");
        exit;
    } else {
        $error = "Error updating order: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Update Order | Admin Panel</title>
<style>
/* 🌿 Global */
body {
  font-family: 'Segoe UI', sans-serif;
  margin: 0;
  background-color: #f8f9fa;
  color: #333;
}

/* 🌳 Navbar */
.navbar {
  background: #145c32;
  color: white;
  padding: 14px 25px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.navbar h1 { font-size: 20px; margin: 0; }
.navbar a {
  background: white;
  color: #145c32;
  padding: 8px 16px;
  border-radius: 6px;
  text-decoration: none;
  font-weight: 500;
  transition: 0.3s;
}
.navbar a:hover { background: #24713f; color: white; }

/* 🌸 Main Section */
.main {
  display: flex;
  justify-content: center;
  align-items: flex-start;
  padding: 60px 20px;
}

/* 📦 Container */
.container {
  background: white;
  padding: 35px;
  border-radius: 12px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.08);
  width: 80%;
  max-width: 600px;
  text-align: center;
}

/* 🧾 Title */
h2 {
  color: #145c32;
  font-size: 24px;
  margin-bottom: 25px;
  border-bottom: 2px solid #e9f5ef;
  display: inline-block;
  padding-bottom: 5px;
}

/* 📝 Form */
form {
  display: flex;
  flex-direction: column;
  align-items: center;
}
select {
  width: 80%;
  padding: 10px;
  margin: 15px 0;
  border-radius: 8px;
  border: 1px solid #ccc;
  font-size: 15px;
}
button {
  background: #145c32;
  color: white;
  border: none;
  padding: 10px 18px;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 500;
  transition: 0.3s;
}
button:hover { background: #24713f; }

/* 🔙 Back Button */
.back-btn {
  display: inline-block;
  background: #6c757d;
  color: white;
  padding: 10px 18px;
  border-radius: 8px;
  text-decoration: none;
  margin-top: 20px;
  font-weight: 500;
  transition: 0.3s;
}
.back-btn:hover { background: #495057; }

/* 💬 Error Message */
.error {
  color: red;
  font-size: 14px;
  margin-top: 10px;
}

/* 🩵 Footer */
footer {
  text-align: center;
  margin-top: 40px;
  color: #777;
  font-size: 14px;
}
</style>
</head>
<body>

<!-- Navbar -->
<div class="navbar">
  <h1>🛠 Update Order — Admin Panel</h1>
  <a href="../logout.php">Logout</a>
</div>

<!-- Main -->
<div class="main">
  <div class="container">
    <h2>Update Order Status</h2>

    <p><b>Order ID:</b> <?= $order['id'] ?></p>
    <p><b>Customer Name:</b> <?= htmlspecialchars($order['customer_name']) ?></p>
    <p><b>Total Price (₹):</b> <?= $order['total_price'] ?></p>
    <p><b>Current Status:</b> <?= htmlspecialchars($order['status']) ?></p>

    <form method="post">
      <select name="status" required>
        <option value="">-- Select New Status --</option>
        <option value="Placed" <?= $order['status'] == 'Placed' ? 'selected' : '' ?>>Placed</option>
        <option value="In Progress" <?= $order['status'] == 'In Progress' ? 'selected' : '' ?>>In Progress</option>
        <option value="Delivered" <?= $order['status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
        <option value="Cancelled" <?= $order['status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
      
      </select>

      <button type="submit">💾 Update Order</button>
    </form>

    <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>

    <a href="orders.php" class="back-btn">← Back to Orders</a>
  </div>
</div>

<footer>
  © <?= date('Y') ?> Restaurant Management System | Update Order
</footer>

</body>
</html>