<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Check Admin Login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$message = "";

// ✅ Handle staff add
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name      = trim($_POST['name']);
    $email     = trim($_POST['email']);
    $phone     = trim($_POST['phone']);
    $role      = trim($_POST['role']);
    $salary    = floatval($_POST['salary']);
    $hire_date = $_POST['hire_date'];
    $status    = $_POST['status'];

    $stmt = $conn->prepare("INSERT INTO staff (name, email, phone, role, salary, hire_date, status) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $email, $phone, $role, $salary, $hire_date, $status);

    if ($stmt->execute()) {

        $default_pw = password_hash("12345", PASSWORD_DEFAULT);

        $stmt2 = $conn->prepare("INSERT INTO users (name, email, password, role, phone, created_at) 
                                 VALUES (?, ?, ?, 'staff', ?, NOW())");
        $stmt2->bind_param("ssss", $name, $email, $default_pw, $phone);
        $stmt2->execute();
        $stmt2->close();

        $message = "✅ Staff added successfully! Default password: 12345";
    } else {
        $message = "❌ Error adding staff: " . $conn->error;
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Staff | Admin Panel</title>

<style>
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    background: #f4f6f9;
}

/* HEADER */
.header {
    background: #1b5e20;
    padding: 15px 25px;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    left: 0; right: 0; top: 0;
    z-index: 1000;
}
.header h1 { margin: 0; font-size: 20px; }
.header a {
    background: white;
    color: #1b5e20;
    padding: 8px 14px;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
}
.header a:hover { background:#2e7d32; color:white; }

/* SIDEBAR */
.sidebar {
    width: 230px;
    background: white;
    height: 100vh;
    position: fixed;
    top: 60px;
    left: 0;
    border-right: 1px solid #ddd;
    padding-top: 10px;
}
.sidebar a {
    display: block;
    padding: 12px 25px;
    text-decoration: none;
    color: #333;
    border-left: 4px solid transparent;
}
.sidebar a:hover,
.sidebar .active {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

/* MAIN */
.main {
    margin-left: 250px;
    padding: 90px 40px 40px;
}

.container {
    max-width: 650px;
    margin: auto;
    background: white;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 3px 12px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
    color: #1b5e20;
}

/* FORM */
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

input, select {
    padding: 10px;
    border: 1px solid #bbb;
    border-radius: 6px;
    font-size: 15px;
}

button {
    background: #1b5e20;
    padding: 12px;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
}
button:hover { background: #145317; }

.message {
    text-align: center;
    margin-bottom: 10px;
    color: #1b5e20;
    font-weight: bold;
}

.back {
    text-align: center;
    display: block;
    margin-top: 15px;
    color: #1b5e20;
    font-weight: bold;
    text-decoration: none;
}
.back:hover { color: #2e7d32; }

</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>👨‍🍳 Admin — Add Staff</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php">🍴 Manage Menu</a>
    <a href="staff.php" class="active">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN -->
<div class="main">
<div class="container">

    <h2>Add New Staff Member</h2>

    <?php if ($message): ?>
        <p class="message"><?= $message ?></p>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="text" name="phone" placeholder="Phone Number" required>

        <label>Role:</label>
        <select name="role" required>
            <option value="">-- Select Role --</option>
            <option value="Manager">Manager</option>
            <option value="Chef">Chef</option>
            <option value="Waiter">Waiter</option>
            <option value="Cleaner">Cleaner</option>
            <option value="Cashier">Cashier</option>
        </select>

        <input type="number" name="salary" placeholder="Salary (₹)" required>

        <label>Hire Date:</label>
        <input type="date" name="hire_date" required>

        <label>Status:</label>
        <select name="status" required>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
        </select>

        <button type="submit">➕ Add Staff</button>
    </form>

    <a href="staff.php" class="back">← Back to Staff</a>

</div>
</div>

</body>
</html>