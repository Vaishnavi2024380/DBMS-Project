<?php
session_start();
require_once __DIR__ . '/../config/db.php';
$id = $_GET['id'];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $status = $_POST['payment_status'];
    $payment_date = $_POST['payment_date'];
    $month = date('F Y');
    $next_due = date('Y-m-d', strtotime('+1 month', strtotime($payment_date)));
    $stmt = $conn->prepare("UPDATE staff SET payment_status=?, payment_date=?, payment_month=?, next_payment_due=? WHERE id=?");
    $stmt->bind_param("ssssi", $status, $payment_date, $month, $next_due, $id);
    if ($stmt->execute()) {
        echo "<script>alert('Payment updated!'); window.location='manage_staff.php';</script>";
    }
}
?>
<form method="POST" style="margin:50px auto;width:400px;">
<h2>Update Payment</h2>
<select name="payment_status" required>
<option value="Paid">Paid</option>
<option value="Pending">Pending</option>
</select><br><br>
<input type="date" name="payment_date" required><br><br>
<button type="submit">Save</button>
</form>