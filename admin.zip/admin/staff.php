<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// Fetch staff
$result = $conn->query("SELECT * FROM staff ORDER BY hire_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Staff | Admin Panel</title>

<style>
body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:#f6fbf6;
}

/* HEADER */
.header{
    background:#1b5e20;
    color:white;
    padding:15px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:fixed;
    top:0;left:0;right:0;
    z-index:1000;
}
.header h1{margin:0;font-size:20px;}
.header a{
    background:white;
    color:#1b5e20;
    padding:8px 14px;
    text-decoration:none;
    border-radius:6px;
    font-weight:bold;
}
.header a:hover{background:#2e7d32;color:white;}

/* SIDEBAR */
.sidebar{
    width:230px;
    background:white;
    position:fixed;
    top:60px; left:0;
    height:100vh;
    border-right:1px solid #ddd;
    padding-top:10px;
}
.sidebar a{
    display:block;
    padding:12px 20px;
    color:#333;
    text-decoration:none;
    border-left:4px solid transparent;
}
.sidebar a:hover,
.sidebar .active{
    background:#e9f5ef;
    border-left:4px solid #1b5e20;
}

/* MAIN AREA */
.main{
    margin-left:250px;
    padding:90px 40px 40px;
}

h2{
    text-align:center;
    color:#1b5e20;
    margin-bottom:20px;
}

.add-btn{
    display:inline-block;
    background:#1b5e20;
    color:white;
    padding:10px 16px;
    border-radius:6px;
    text-decoration:none;
    font-weight:500;
    margin-bottom:15px;
}
.add-btn:hover{background:#145317;}

/* TABLE */
.table{
    width:100%;
    border-collapse:collapse;
    background:white;
    box-shadow:0 2px 6px rgba(0,0,0,0.1);
}
.table th,.table td{
    border:1px solid #e2e2e2;
    padding:10px;
    text-align:center;
}
.table th{
    background:#eaf6ea;
    color:#1b5e20;
}

/* Status badges */
.status-active{color:green;font-weight:bold;}
.status-inactive{color:red;font-weight:bold;}

/* Action buttons */
.btn-edit{
    background:#1976d2;
    color:white;
    text-decoration:none;
    padding:6px 10px;
    border-radius:6px;
}
.btn-edit:hover{background:#0f58a9;}

.btn-delete{
    background:#d32f2f;
    color:white;
    text-decoration:none;
    padding:6px 10px;
    border-radius:6px;
}
.btn-delete:hover{background:#9a2121;}
</style>

</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>👨‍🍳 Admin — Manage Staff</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">

    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php">🍴 Manage Menu</a>
    <a href="staff.php" class="active">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>

</div>

<!-- MAIN CONTENT -->
<div class="main">

    <h2>Staff Management</h2>

    <a href="add_staff.php" class="add-btn">➕ Add New Staff</a>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Role</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Salary (₹)</th>
                <th>Hire Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['role']) ?></td>
                        <td><?= htmlspecialchars($row['email']) ?></td>
                        <td><?= htmlspecialchars($row['phone']) ?></td>
                        <td><?= number_format($row['salary'],2) ?></td>
                        <td><?= $row['hire_date'] ?></td>

                        <td class="<?= strtolower($row['status'])=='active' ? 'status-active':'status-inactive' ?>">
                            <?= $row['status'] ?>
                        </td>

                        <td>
                            <a href="edit_staff.php?id=<?= $row['id'] ?>" class="btn-edit">✏ Edit</a>
                            <a href="delete_staff.php?id=<?= $row['id'] ?>" class="btn-delete"
                                onclick="return confirm('Delete this staff?');">🗑 Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="9">No staff found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>