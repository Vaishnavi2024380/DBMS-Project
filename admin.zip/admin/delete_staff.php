<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Check if Admin is Logged In
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

// ✅ Check if ID Exists
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>alert('⚠️ Invalid request.'); window.location.href='staff.php';</script>";
    exit;
}

$id = intval($_GET['id']);

// ✅ Delete the Staff Record
$stmt = $conn->prepare("DELETE FROM staff WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "<script>alert('🗑️ Staff record deleted successfully!'); window.location.href='staff.php';</script>";
} else {
    echo "<script>alert('❌ Error deleting staff record.'); window.location.href='staff.php';</script>";
}
$stmt->close();
$conn->close();
?>