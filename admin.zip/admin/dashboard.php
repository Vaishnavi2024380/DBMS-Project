<?php  
session_start();  
require_once __DIR__ . '/../config/db.php';  

// Check Admin Login  
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {  
    header("Location: ../login.php");  
    exit;  
}  

$name = $_SESSION['name'];  
$role = $_SESSION['role'];  

// Simple count function  
function getCount($conn, $query) {  
    $result = mysqli_query($conn, $query);  
    return ($result) ? mysqli_fetch_row($result)[0] : 0;  
}  

// Dashboard counts  
$total_orders      = getCount($conn, "SELECT COUNT(*) FROM orders");  
$total_customers   = getCount($conn, "SELECT COUNT(*) FROM users WHERE role='customer'");  
$total_staff       = getCount($conn, "SELECT COUNT(*) FROM staff");  
$total_menu        = getCount($conn, "SELECT COUNT(*) FROM menu_items");  
$total_feedback    = getCount($conn, "SELECT COUNT(*) FROM feedback");  
$total_tables      = getCount($conn, "SELECT COUNT(*) FROM tables");  
$total_special     = getCount($conn, "SELECT COUNT(*) FROM menu_items WHERE today_special = 1"); // ⭐ New  

// Get last login  
$q = mysqli_query($conn, "SELECT last_login FROM users WHERE id = " . $_SESSION['user_id']);  
$last_login = ($r = mysqli_fetch_assoc($q)) ? $r['last_login'] : "N/A";  
?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
<meta charset="UTF-8">  
<title>Admin Dashboard | Restaurant Management</title>  
<style>  
body {  
    font-family: 'Segoe UI', sans-serif;  
    margin: 0;  
    background: #f8f9fa;  
    color: #333;  
}

/* Navbar */  
.navbar {  
    background: #145a32;  
    color: white;  
    padding: 12px 25px;  
    display: flex;  
    justify-content: space-between;  
    align-items: center;  
}  
.navbar h1 { margin: 0; font-size: 20px; }  
.navbar a {  
    background: white;  
    color: #145a32;  
    padding: 8px 14px;  
    border-radius: 6px;  
    text-decoration: none;  
    font-weight: 500;  
}  
.navbar a:hover { background:#145a32;color:white; }

/* Sidebar */  
.sidebar {  
    width: 230px;  
    background: white;  
    border-right: 1px solid #ddd;  
    height: 100vh;  
    position: fixed;  
    top: 55px;  
    left: 0;  
    padding-top: 20px;  
}  
.sidebar a {  
    display: block;  
    padding: 12px 25px;  
    color: #333;  
    text-decoration: none;  
    border-left: 4px solid transparent;  
}  
.sidebar a:hover, .sidebar .active {  
    background: #e9f5ef;  
    border-left: 4px solid #145a32;  
}

/* Main area */  
.main {  
    margin-left: 250px;  
    padding: 40px;  
}  
h2 { color: #145a32; margin-bottom: 10px; }  

.cards {  
    display: grid;  
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));  
    gap: 20px;  
    margin-top: 25px;  
}  
.card {  
    background: white;  
    border: 1px solid #dcdcdc;  
    padding: 18px;  
    border-radius: 10px;  
    text-align: center;  
    box-shadow: 0 2px 6px rgba(0,0,0,0.08);  
    transition: 0.3s ease;  
}  
.card:hover {  
    transform: scale(1.04);  
    box-shadow: 0 3px 10px rgba(0,0,0,0.12);  
}  
.card h3 { color:#145a32;margin:0;font-size:18px; }  
.card p { font-size:24px;font-weight:bold; }  

footer {  
    text-align: center;  
    margin-top: 40px;  
    color: #666;  
}  
</style>  
</head>  
<body>  

<div class="navbar">  
    <h1>🍽 Restaurant Management System — Admin</h1>  
    <a href="../logout.php">Logout</a>  
</div>  

<div class="sidebar">  
    <a href="dashboard.php" class="active">🏠 Dashboard</a>  
    <a href="orders.php">📦 Orders</a>  
    <a href="manage_menu.php">🍕 Manage Menu</a>  
    <a href="staff.php">👨‍🍳 Staff</a>  
    <a href="customers.php">👥 Customers</a>  
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>  
    <a href="feedback.php">💬 Feedback</a>  
    <a href="reports.php">📊 Reports</a>  
    <a href="change_password.php">🔑 Change Password</a>  
</div>  

<div class="main">  
    <h2>👋 Welcome, <?= htmlspecialchars($name) ?>!</h2>  
    <p><b>Role:</b> <?= htmlspecialchars($role) ?> | <b>Last Login:</b> <?= $last_login ?></p>  

    <div class="cards">  
        <div class="card"><h3>📦 Orders</h3><p><?= $total_orders ?></p></div>  
        <div class="card"><h3>🍕 Menu Items</h3><p><?= $total_menu ?></p></div>  
        <div class="card"><h3>⭐ Today's Special</h3><p><?= $total_special ?></p></div>  
        <div class="card"><h3>👥 Customers</h3><p><?= $total_customers ?></p></div>  
        <div class="card"><h3>👨‍🍳 Staff</h3><p><?= $total_staff ?></p></div>  
        <div class="card"><h3>🪑 Tables</h3><p><?= $total_tables ?></p></div>  
        <div class="card"><h3>💬 Feedback</h3><p><?= $total_feedback ?></p></div>  
    </div>  

    <footer>© <?= date('Y') ?> Restaurant Management System | Admin Dashboard</footer>  
</div>  

</body>  
</html>