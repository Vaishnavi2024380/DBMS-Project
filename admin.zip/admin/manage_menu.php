See see<?php
session_start();
require_once __DIR__ . '/../config/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Fetch menu grouped by categories
$query = "SELECT c.id AS cat_id, c.name AS category, 
                 m.id AS item_id, m.category AS item_name, m.price, 
                 m.description, m.image 
          FROM categories c 
          LEFT JOIN menu_items m ON c.id = m.category_id 
          ORDER BY c.name ASC, m.category ASC";

$result = $conn->query($query);

$menu = [];
while ($row = $result->fetch_assoc()) {
    $menu[$row['category']][] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>🍴 Manage Menu | Admin Panel</title>

<style>
/* ===========================
   GLOBAL
=========================== */
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    background: #f4f6f9;
    color: #333;
}

/* ===========================
   HEADER
=========================== */
.header {
    background: #1b5e20;
    color: white;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
}
.header h1 {
    margin: 0;
    font-size: 20px;
}
.header a {
    background: white;
    color: #1b5e20;
    padding: 8px 14px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
}
.header a:hover {
    background: #2e7d32;
    color: white;
}

/* ===========================
   SIDEBAR
=========================== */
.sidebar {
    width: 230px;
    background: white;
    border-right: 1px solid #dcdcdc;
    height: 100vh;
    position: fixed;
    top: 60px;
    left: 0;
    padding-top: 10px;
}
.sidebar a {
    display: block;
    padding: 12px 25px;
    color: #333;
    text-decoration: none;
    border-left: 4px solid transparent;
    transition: 0.3s;
}
.sidebar a:hover,
.sidebar .active {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

/* ===========================
   MAIN CONTENT
=========================== */
.main {
    margin-left: 250px;
    padding: 80px 40px;
}
.container {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.top-buttons {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 20px;
    gap: 10px;
}

.btn {
    padding: 8px 14px;
    border-radius: 6px;
    color: white;
    text-decoration: none;
    font-weight: 500;
}
.btn-add { background: #1b5e20; }
.btn-add:hover { background: #145a16; }
.btn-edit { background: #1976d2; }
.btn-edit:hover { background: #125a9e; }
.btn-del { background: #d32f2f; }
.btn-del:hover { background: #9a2424; }

/* ===========================
   CATEGORY SECTION
=========================== */
.category {
    margin-top: 25px;
}

.category h2 {
    color: #1b5e20;
    border-left: 5px solid #1b5e20;
    padding-left: 10px;
    margin-bottom: 12px;
    font-size: 20px;
}

/* ===========================
   TABLE
=========================== */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 30px;
}

th, td {
    border: 1px solid #eee;
    padding: 12px;
    text-align: left;
}
th {
    background: #eaf6ea;
    color: #1b5e20;
}
tr:hover {
    background: #f8faf8;
}

img.thumb {
    width: 90px;
    height: 70px;
    object-fit: cover;
    border-radius: 6px;
    border: 1px solid #ccc;
}

.actions {
    display: flex;
    gap: 10px;
}

/* ===========================
   FOOTER
=========================== */
footer {
    text-align: center;
    padding: 20px;
    background: #1b5e20;
    color: white;
    border-top: 3px solid #145314;
    margin-top: 40px;
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>🍽 Restaurant Admin — Manage Menu</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php" class="active">🍕 Manage Menu</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">
<div class="container">

    <div class="top-buttons">
        <a href="add_category.php" class="btn btn-add">➕ Add Category</a>
        <a href="add_menu.php" class="btn btn-add">🍕 Add Menu Item</a>
    </div>

    <?php if (empty($menu)): ?>
        <p>No categories or menu items found.</p>
    <?php else: ?>
        <?php foreach ($menu as $category => $items): ?>
            <div class="category">
                <h2>📂 <?= htmlspecialchars($category) ?></h2>

                <table>
                    <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>Item Name</th>
                        <th>Price (₹)</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>

                    <?php foreach ($items as $item): ?>
                    <tr>
                        <td><?= $item['item_id'] ?></td>
                        <td>
                            <?php if (!empty($item['image'])): ?>
                                <img class="thumb" src="../assets/images/menu/<?= htmlspecialchars($item['image']) ?>">
                            <?php else: ?>
                                <span>No Image</span>
                            <?php endif; ?>
                        </td>

                        <td><?= htmlspecialchars($item['item_name']) ?></td>
                        <td>₹<?= number_format($item['price'], 2) ?></td>
                        <td><?= nl2br(htmlspecialchars($item['description'])) ?></td>

                        <td class="actions">
                            <a href="edit_menu.php?id=<?= $item['item_id'] ?>" class="btn btn-edit">✏️ Edit</a>
                            <a href="delete_menu.php?id=<?= $item['item_id'] ?>" class="btn btn-del" onclick="return confirm('Delete this item?')">🗑 Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>

                </table>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

</div>
</div>

<footer>
    © <?= date('Y') ?> Restaurant Management System | Admin Panel
</footer>

</body>
</html>