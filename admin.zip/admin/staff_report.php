<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Restrict to admin
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Fetch staff data
$result = $conn->query("SELECT * FROM staff ORDER BY role ASC, name ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>📄 Staff Report | Admin Panel</title>
<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background: #f4f6f9;
    margin: 0;
    color: #333;
}
.container {
    width: 95%;
    margin: 30px auto;
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}
h1 {
    text-align: center;
    color: #2c3e50;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 25px;
}
th, td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}
th {
    background: #2c3e50;
    color: white;
}
tr:nth-child(even) { background: #f8f9fa; }

.btn-print {
    display: inline-block;
    margin-bottom: 15px;
    background: #27ae60;
    color: white;
    padding: 10px 15px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
}
.btn-print:hover {
    background: #1e8449;
}
.back-btn {
    background: #e67e22;
    color: white;
    padding: 10px 15px;
    border-radius: 6px;
    text-decoration: none;
}
.back-btn:hover {
    background: #ca6f1e;
}
footer {
    text-align: center;
    margin-top: 25px;
    color: gray;
    font-size: 14px;
}
@media print {
    .btn-print, .back-btn, footer {
        display: none;
    }
    body {
        background: white;
    }
    table {
        border: 1px solid #000;
    }
}
</style>
</head>
<body>
<div class="container">
    <h1>👨‍🍳 Restaurant Staff Salary Report</h1>
    <p><b>Generated on:</b> <?= date("F d, Y h:i A") ?></p>

    <a href="#" class="btn-print" onclick="window.print()">🖨️ Print Report</a>
    <a href="manage_staff.php" class="back-btn">🔙 Back to Manage Staff</a>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Role</th>
            <th>Phone</th>
            <th>Join Date</th>
            <th>Salary (₹)</th>
            <th>Month</th>
            <th>Last Payment Date</th>
            <th>Status</th>
        </tr>

        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= htmlspecialchars($row['role']) ?></td>
                <td><?= htmlspecialchars($row['phone']) ?></td>
                <td><?= $row['join_date'] ?></td>
                <td>₹<?= number_format($row['salary'], 2) ?></td>
                <td><?= htmlspecialchars($row['payment_month']) ?></td>
                <td><?= $row['last_payment_date'] ?: "—" ?></td>
                <td style="color:<?= ($row['payment_status'] == 'Paid') ? 'green' : 'red' ?>;">
                    <?= $row['payment_status'] ?>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="9" style="text-align:center;">No staff records found</td></tr>
        <?php endif; ?>
    </table>
</div>

<footer>© <?= date('Y') ?> Restaurant Management System | Staff Payment Report</footer>
</body>
</html>