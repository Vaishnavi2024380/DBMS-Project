<?php
session_start();
require_once __DIR__ . '/../config/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("Invalid menu item ID.");
}

$item_id = intval($_GET['id']);

// Fetch existing item details
$query = "SELECT * FROM menu_items WHERE id = $item_id";
$result = $conn->query($query);

if ($result->num_rows === 0) {
    die("Menu item not found.");
}

$item = $result->fetch_assoc();

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_id  = $_POST['category_id'];
    $category     = $_POST['category'];
    $price        = $_POST['price'];
    $description  = $_POST['description'];
    $image        = $item['image'];

    // Image upload
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "../assets/images/menu/";
        $target_file = $target_dir . basename($_FILES['image']['name']);

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image = basename($_FILES['image']['name']);
        }
    }

    // Update query
    $update = "UPDATE menu_items SET 
                  category_id = '$category_id',
                  category    = '$category',
                  price       = '$price',
                  description = '$description',
                  image       = '$image'
               WHERE id = $item_id";

    if ($conn->query($update)) {
        echo "<script>alert('Menu item updated successfully!'); window.location='manage_menu.php';</script>";
    } else {
        echo "<script>alert('Error updating item.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>✏️ Edit Menu Item | Admin Panel</title>

<style>
/* GLOBAL */
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    background: #f4f6f9;
}

/* HEADER */
.header {
    background: #1b5e20;
    padding: 15px 25px;
    color: white;
    display: flex;
    justify-content: space-between;
    position: fixed;
    top: 0; left: 0; right: 0;
    z-index: 1000;
}
.header h1 { margin: 0; font-size: 20px; }
.header a {
    background: white;
    color: #1b5e20;
    padding: 8px 14px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
}
.header a:hover { background: #2e7d32; color: white; }

/* SIDEBAR */
.sidebar {
    width: 230px;
    background: white;
    height: 100vh;
    position: fixed;
    top: 60px;
    left: 0;
    border-right: 1px solid #dcdcdc;
    padding-top: 10px;
}
.sidebar a {
    display: block;
    padding: 12px 25px;
    text-decoration: none;
    color: #333;
    border-left: 4px solid transparent;
    transition: 0.3s;
}
.sidebar a:hover,
.sidebar .active {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

/* MAIN CONTENT */
.main {
    margin-left: 250px;
    padding: 90px 40px;
}

.container {
    max-width: 700px;
    margin: auto;
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
    color: #1b5e20;
}

/* FORM */
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}
label { font-weight: bold; }

input[type="text"],
input[type="number"],
textarea {
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 6px;
}

button {
    padding: 10px;
    background: #1b5e20;
    border: none;
    color: white;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
}
button:hover { background: #145a18; }

/* IMAGE */
.preview {
    width: 120px;
    height: 90px;
    border-radius: 6px;
    object-fit: cover;
    border: 1px solid #ccc;
}

/* BACK LINK */
.back {
    display: block;
    margin-top: 20px;
    text-align: center;
    font-weight: bold;
    color: #1b5e20;
    text-decoration: none;
}
.back:hover { color: #2e7d32; }
</style>
</head>

<body>

<!-- HEADER -->
<div class="header">
    <h1>✏️ Edit Menu Item</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php" class="active">🍕 Manage Menu</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN AREA -->
<div class="main">

<div class="container">
    <h2>Edit Menu Item</h2>

    <form method="POST" enctype="multipart/form-data">

        <label>Category ID:</label>
        <input type="number" name="category_id" value="<?= $item['category_id'] ?>" required>

        <label>Category Name:</label>
        <input type="text" name="category" value="<?= $item['category'] ?>" required>

        <label>Price (₹):</label>
        <input type="number" name="price" value="<?= $item['price'] ?>" required>

        <label>Description:</label>
        <textarea name="description" rows="4"><?= $item['description'] ?></textarea>

        <label>Current Image:</label>
        <?php if ($item['image']): ?>
            <img src="../assets/images/menu/<?= $item['image'] ?>" class="preview">
        <?php else: ?>
            <p>No image available</p>
        <?php endif; ?>

        <label>Upload New Image:</label>
        <input type="file" name="image" accept="image/*">

        <button type="submit">💾 Update Menu Item</button>
    </form>

    <a href="manage_menu.php" class="back">← Back to Menu</a>
</div>

</div>

</body>
</html>