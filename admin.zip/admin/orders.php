<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Check admin login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Handle order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['status'])) {
    $order_id = intval($_POST['order_id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    mysqli_query($conn, "UPDATE orders SET status='$status' WHERE id=$order_id");
    header("Location: orders.php");
    exit;
}

// Fetch all orders
$orders_res = mysqli_query($conn, "SELECT * FROM orders ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>All Orders | Admin Panel</title>
<style>
body {
  font-family: 'Poppins', sans-serif;
  margin: 0;
  background: #f6fbf6;
  color: #333;
}

/* ===== HEADER ===== */
.header {
  background: #1b5e20;
  color: white;
  padding: 15px 25px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
}
.header h3 { margin: 0; font-size: 20px; }
.header a {
  background: white;
  color: #1b5e20;
  padding: 8px 14px;
  border-radius: 6px;
  text-decoration: none;
  font-weight: bold;
}
.header a:hover { background: #2e7d32; color: white; }

/* ===== SIDEBAR ===== */
.sidebar {
  width: 230px;
  background: white;
  border-right: 1px solid #dcdcdc;
  height: 100vh;
  position: fixed;
  top: 60px;
  left: 0;
  padding-top: 15px;
}
.sidebar a {
  display: block;
  padding: 12px 25px;
  color: #333;
  text-decoration: none;
  border-left: 4px solid transparent;
  transition: 0.3s;
}
.sidebar a:hover,
.sidebar .active {
  background: #e9f5ef;
  border-left: 4px solid #1b5e20;
}

/* ===== MAIN CONTENT ===== */
.main {
  margin-left: 250px;
  padding: 80px 40px;
}
.container {
  background: white;
  padding: 25px;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

h2 {
  text-align: center;
  color: #1b5e20;
  font-size: 24px;
}

/* ===== TABLE ===== */
.table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}
.table th, .table td {
  border: 1px solid #e8eee8;
  padding: 10px;
  text-align: center;
}
.table th {
  background: #eaf6ea;
  color: #1b5e20;
  font-weight: bold;
}

/* ===== BUTTONS ===== */
.btn {
  padding: 6px 10px;
  border-radius: 6px;
  border: none;
  color: white;
  cursor: pointer;
  font-weight: 600;
}
.btn-view { background: #2e7d32; }
.btn-update { background: #1976d2; }
.btn-bill { background: #3c39deff; }
.btn-bill:hover { background: #1b1918ff; }

.btn:hover { opacity: 0.9; }

.back-btn {
  display: inline-block;
  margin-top: 20px;
  background: #1b5e20;
  color: white;
  padding: 8px 16px;
  border-radius: 20px;
  text-decoration: none;
}
.back-btn:hover { background: #2e7d32; }

/* ===== STATUS COLORS ===== */
.status-placed { color: #d84315; font-weight: bold; }
.status-inprogress { color: #f9a825; font-weight: bold; }
.status-accepted { color: #7b1fa2; font-weight: bold; }
.status-delivered { color: green; font-weight: bold; }
.status-cancelled { color: #9e9e9e; text-decoration: line-through; }

/* ===== MODAL ===== */
.modal-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.4);
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 999;
}
.modal {
  background: white;
  padding: 22px;
  border-radius: 10px;
  width: 360px;
  box-shadow: 0 8px 20px rgba(0,0,0,0.12);
}
.modal h3 { color: #1b5e20; margin-top: 0; }
.select {
  width: 100%;
  padding: 8px;
  border-radius: 6px;
  border: 1px solid #ccc;
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
  <h3>🍽️ Restaurant Management — Admin Panel</h3>
  <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php" class="active">📦 Orders</a>
    <a href="manage_menu.php">🍕 Manage Menu</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">
<div class="container">

  <h2>All Orders</h2>

  <table class="table">
    <thead>
      <tr>
        <th>Order ID</th>
        <th>Order Date</th>
        <th>Customer</th>
        <th>Table No</th>
        <th>Items</th>
        <th>Total (₹)</th>
        <th>Assigned To</th>
        <th>Status</th>
        <th>Bill</th>
        <th>Action</th>
      </tr>
    </thead>

    <tbody>
      <?php if ($orders_res && mysqli_num_rows($orders_res) > 0): ?>
        <?php while ($o = mysqli_fetch_assoc($orders_res)): ?>
          <?php $status_class = strtolower(str_replace(' ', '', $o['status'])); ?>
          <tr>
            <td><?= $o['id'] ?></td>
            <td><?= $o['order_date'] ?></td>
            <td><?= htmlspecialchars($o['customer_name']) ?></td>
            <td><?= htmlspecialchars($o['table_no']) ?></td>
            <td><?= $o['total_items'] ?></td>
            <td><?= $o['total_price'] ?></td>
            <td><?= !empty($o['assigned_to']) ? htmlspecialchars($o['assigned_to']) : '-' ?></td>
            <td class="status-<?= $status_class ?>"><?= htmlspecialchars($o['status']) ?></td>

            <!-- NEW BILL BUTTON -->
            <td>
                <a href="view_bill.php?id=<?= $o['id'] ?>" class="btn btn-bill">Bill</a>
            </td>

            <td>
              <a href="view_order.php?id=<?= $o['id'] ?>" class="btn btn-view">View</a>
              <button class="btn btn-update" onclick="openModal(<?= $o['id'] ?>, '<?= addslashes($o['status']) ?>')">Update</button>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="10">No orders found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>

</div>
</div>

<!-- MODAL -->
<div id="modalBackdrop" class="modal-backdrop">
  <div class="modal">
    <h3>Update Order Status</h3>
    <form method="POST">
      <input type="hidden" name="order_id" id="order_id">

      <label for="status">Select Status:</label>
      <select name="status" id="status" class="select">
        <option value="Placed">Placed</option>
        <option value="Accepted">Accepted</option>
        <option value="In Progress">In Progress</option>
        <option value="Delivered">Delivered</option>
        <option value="Cancelled">Cancelled</option>
      </select>

      <div style="margin-top:12px;text-align:right;">
        <button type="button" onclick="closeModal()" style="padding:7px 10px;border:none;border-radius:6px;background:#ccc;">Close</button>
        <button type="submit" class="btn btn-update">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
function openModal(orderId, currentStatus) {
  document.getElementById('order_id').value = orderId;

  const statusSelect = document.getElementById('status');
  [...statusSelect.options].forEach(opt => {
    if (opt.value === currentStatus) opt.selected = true;
  });

  document.getElementById('modalBackdrop').style.display = 'flex';
}
function closeModal() {
  document.getElementById('modalBackdrop').style.display = 'none';
}
document.getElementById('modalBackdrop').addEventListener('click', (e) => {
  if (e.target === document.getElementById('modalBackdrop')) closeModal();
});
</script>

</body>
</html>