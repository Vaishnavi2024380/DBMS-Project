<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// 🔐 Check Admin Login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: staff.php");
    exit;
}

$id = intval($_GET['id']);
$msg = "";

// Fetch Staff
$stmt = $conn->prepare("SELECT * FROM staff WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
$staff = $res->fetch_assoc();
$stmt->close();

if (!$staff) {
    echo "<script>alert('❌ Staff not found'); window.location='staff.php';</script>";
    exit;
}

// Handle Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $role = $_POST['role'];
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $salary = floatval($_POST['salary']);
    $hire_date = $_POST['hire_date'];
    $status = $_POST['status'];

    if (empty($name) || empty($role) || empty($email) || empty($phone) || empty($salary)) {
        $msg = "⚠️ All fields are required.";
    } else {
        $query = "UPDATE staff SET name=?, role=?, email=?, phone=?, salary=?, hire_date=?, status=? WHERE id=?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssssi", $name, $role, $email, $phone, $salary, $hire_date, $status, $id);

        if ($stmt->execute()) {
            echo "<script>alert('✅ Updated successfully!'); window.location='staff.php';</script>";
            exit;
        } else {
            $msg = "❌ Error updating staff.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Staff | Admin Panel</title>

<style>
body {
    margin: 0;
    font-family: 'Poppins', sans-serif;
    background: #f4f6f9;
}

/* HEADER */
.header {
    background: #1b5e20;
    padding: 15px 25px;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    left: 0; right: 0; top: 0;
    z-index: 1000;
}
.header h1 { margin: 0; font-size: 20px; }
.header a {
    background: white;
    color: #1b5e20;
    padding: 8px 14px;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
}
.header a:hover { background:#2e7d32; color:white; }

/* SIDEBAR */
.sidebar {
    width: 230px;
    background: white;
    height: 100vh;
    position: fixed;
    top: 60px;
    left: 0;
    border-right: 1px solid #ddd;
    padding-top: 10px;
}
.sidebar a {
    display: block;
    padding: 12px 25px;
    text-decoration: none;
    color: #333;
    border-left: 4px solid transparent;
}
.sidebar a:hover,
.sidebar .active {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

/* MAIN */
.main {
    margin-left: 250px;
    padding: 100px 40px 40px;
}

.container {
    width: 60%;
    margin: auto;
    background: white;
    padding: 35px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
    color: #1b5e20;
    margin-bottom: 20px;
}

form {
    display: flex;
    flex-direction: column;
    gap: 14px;
}

label {
    font-weight: bold;
    color: #1b5e20;
}

input, select {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 15px;
}

button {
    padding: 10px;
    background: #1b5e20;
    color: white;
    border: none;
    border-radius: 6px;
    font-weight: 500;
    cursor: pointer;
}
button:hover { background:#145317; }

.message {
    text-align: center;
    color: red;
    font-weight: bold;
}

/* BACK BUTTON */
.back-btn {
    display: block;
    margin-top: 20px;
    font-size: 15px;
    color: #1b5e20;
    text-decoration: none;
    font-weight: 500;
}

.back-btn:hover {
    color: #145317;
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>👨‍🍳 Admin — Edit Staff</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php">🍴 Manage Menu</a>
    <a href="staff.php" class="active">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN -->
<div class="main">

<div class="container">

    <h2>Edit Staff Details</h2>

    <?php if($msg): ?>
        <p class="message"><?= $msg ?></p>
    <?php endif; ?>

    <form method="POST">

        <label>Full Name:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($staff['name']) ?>" required>

        <label>Role:</label>
        <select name="role" required>
            <option value="Waiter" <?= ($staff['role']=='Waiter')?'selected':''; ?>>Waiter</option>
            <option value="Chef" <?= ($staff['role']=='Chef')?'selected':''; ?>>Chef</option>
            <option value="Cashier" <?= ($staff['role']=='Cashier')?'selected':''; ?>>Cashier</option>
            <option value="Manager" <?= ($staff['role']=='Manager')?'selected':''; ?>>Manager</option>
        </select>

        <label>Email:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($staff['email']) ?>" required>

        <label>Phone:</label>
        <input type="text" name="phone" value="<?= htmlspecialchars($staff['phone']) ?>" required>

        <label>Salary (₹):</label>
        <input type="number" step="0.01" name="salary" value="<?= $staff['salary'] ?>" required>

        <label>Hire Date:</label>
        <input type="date" name="hire_date" value="<?= $staff['hire_date'] ?>" required>

        <label>Status:</label>
        <select name="status" required>
            <option value="Active" <?= ($staff['status']=='Active')?'selected':''; ?>>Active</option>
            <option value="Inactive" <?= ($staff['status']=='Inactive')?'selected':''; ?>>Inactive</option>
        </select>

        <button type="submit">💾 Update Staff</button>

    </form>

    <!-- BACK BUTTON -->
    <a href="staff.php" class="back-btn">← Back to Staff List</a>

</div>

</div>

</body>
</html>