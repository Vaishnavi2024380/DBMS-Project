<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Only admin allowed
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Summary counts
$total_orders = mysqli_fetch_row(mysqli_query($conn, "SELECT COUNT(*) FROM orders"))[0];
$total_sales = mysqli_fetch_row(mysqli_query($conn, "SELECT IFNULL(SUM(total_price), 0) FROM orders"))[0];

// Best Selling Items
$top_items = mysqli_query($conn, "
    SELECT item_name AS name, COUNT(item_name) AS sold_count
    FROM order_items
    GROUP BY item_name
    ORDER BY sold_count DESC
    LIMIT 5
");

// Recent orders
$recent_orders = mysqli_query($conn, "
    SELECT id, customer_name, table_no, total_price, order_date
    FROM orders
    ORDER BY order_date DESC
    LIMIT 5
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>📊 Reports | Admin Panel</title>

<style>
body {
    margin: 0;
    background: #f4f6f9;
    font-family: 'Poppins', sans-serif;
}

/* HEADER */
.header {
    background: #1b5e20;
    color: white;
    padding: 15px 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    top: 0; left: 0; right: 0;
    z-index: 1000;
}
.header h1 {
    margin: 0;
    font-size: 20px;
}
.header a {
    background: white;
    color: #1b5e20;
    padding: 8px 14px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
}

/* SIDEBAR */
.sidebar {
    width: 230px;
    background: white;
    height: 100vh;
    position: fixed;
    top: 60px;
    left: 0;
    border-right: 1px solid #ddd;
    padding-top: 10px;
}
.sidebar a {
    display: block;
    padding: 12px 25px;
    text-decoration: none;
    color: #333;
    border-left: 4px solid transparent;
}
.sidebar a:hover,
.sidebar .active {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

/* MAIN */
.main {
    margin-left: 250px;
    padding: 90px 40px 40px;
}

h2 {
    color: #1b5e20;
    margin-bottom: 20px;
}

/* SUMMARY CARDS */
.card-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 20px;
}
.card {
    background: white;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
    text-align: center;
}
.card h3 {
    margin: 0;
    color: #1b5e20;
}
.card p {
    margin: 10px 0 0;
    font-size: 22px;
    font-weight: bold;
}

/* TABLE SECTION */
.box {
    background: white;
    padding: 25px;
    margin-top: 35px;
    border-radius: 12px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}
th, td {
    padding: 12px;
    border-bottom: 1px solid #eee;
    text-align: center;
}
th {
    background: #eaf6ea;
    color: #1b5e20;
}
tr:hover {
    background: #f7fdf7;
}

footer {
    margin-top: 30px;
    text-align: center;
    color: #777;
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>📊 Reports — Admin Panel</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR (Correct Order Based on Your UI) -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php">🍴 Manage Menu</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today’s Special Menu</a>
    <a href="feedback.php">💬 Feedback</a>
    <a href="reports.php" class="active">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">

<h2>📈 Restaurant Performance Summary</h2>

<div class="card-container">
    <div class="card">
        <h3>Total Orders</h3>
        <p><?= $total_orders ?></p>
    </div>

    <div class="card">
        <h3>Total Sales (₹)</h3>
        <p><?= number_format($total_sales, 2) ?></p>
    </div>
</div>

<!-- TOP SELLING ITEMS -->
<div class="box">
    <h3>🔥 Top Selling Items</h3>
    <table>
        <tr>
            <th>Item</th>
            <th>Sold Count</th>
        </tr>

        <?php if (mysqli_num_rows($top_items) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($top_items)): ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= $row['sold_count'] ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="2">No data available</td></tr>
        <?php endif; ?>
    </table>
</div>

<!-- RECENT ORDERS -->
<div class="box">
    <h3>🕒 Recent Orders</h3>
    <table>
        <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Table</th>
            <th>Total (₹)</th>
            <th>Date</th>
        </tr>

        <?php if (mysqli_num_rows($recent_orders) > 0): ?>
            <?php while($r = mysqli_fetch_assoc($recent_orders)): ?>
                <tr>
                    <td><?= $r['id'] ?></td>
                    <td><?= htmlspecialchars($r['customer_name']) ?></td>
                    <td><?= htmlspecialchars($r['table_no']) ?></td>
                    <td><?= $r['total_price'] ?></td>
                    <td><?= $r['order_date'] ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="5">No recent orders</td></tr>
        <?php endif; ?>
    </table>
</div>

<footer>© <?= date('Y') ?> Restaurant Management System | Reports</footer>

</div>

</body>
</html>