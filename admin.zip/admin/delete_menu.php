<?php
session_start();
require_once __DIR__ . '/../config/db.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header("Location: ../login.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = mysqli_query($conn, "DELETE FROM menu_items WHERE id=$id");
    echo "<script>alert('🗑 Item deleted successfully!'); window.location='manage_menu.php';</script>";
}
?>