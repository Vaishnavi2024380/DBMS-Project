<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Admin login check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Rating Filter
$rating_filter = "";
$where = "";

if (isset($_GET['rating']) && is_numeric($_GET['rating'])) {
    $rating_filter = intval($_GET['rating']);
    $where = "WHERE rating = $rating_filter";
}

$query = "SELECT * FROM feedback $where ORDER BY date_submitted DESC";
$result = mysqli_query($conn, $query);

// Average rating
$avg_result = mysqli_query($conn, "SELECT AVG(rating) AS avg_rating FROM feedback");
$avg_row = mysqli_fetch_assoc($avg_result);
$avg_rating = round($avg_row['avg_rating'], 1);

// Delete feedback
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    mysqli_query($conn, "DELETE FROM feedback WHERE id = $id");
    header("Location: feedback.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Feedback | Admin Panel</title>

<style>
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    background: #f6fbf6;
}

/* HEADER */
.header {
    background: #1b5e20;
    padding: 15px 25px;
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    top: 0; left: 0; right: 0;
    z-index: 1000;
}
.header h1 { margin: 0; font-size: 20px; }
.header a {
    background: white;
    color: #1b5e20;
    padding: 8px 14px;
    border-radius: 6px;
    text-decoration: none;
    font-weight: bold;
}

/* SIDEBAR */
.sidebar {
    width: 230px;
    background: white;
    height: 100vh;
    position: fixed;
    top: 60px;
    left: 0;
    border-right: 1px solid #ddd;
    padding-top: 10px;
}
.sidebar a {
    display: block;
    padding: 12px 25px;
    color: #333;
    text-decoration: none;
    border-left: 4px solid transparent;
}
.sidebar a:hover,
.sidebar .active {
    background: #e9f5ef;
    border-left: 4px solid #1b5e20;
}

/* MAIN AREA */
.main {
    margin-left: 250px;
    padding: 90px 40px 40px;
}

.container {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

h2 {
    text-align: center;
    color: #1b5e20;
}

/* FILTER BUTTONS */
.filter-box {
    text-align: center;
    margin: 20px 0;
}
.filter-btn {
    padding: 8px 14px;
    border-radius: 20px;
    text-decoration: none;
    background: #e9f5ef;
    border: 1px solid #1b5e20;
    color: #1b5e20;
    margin: 3px;
    display: inline-block;
    font-weight: 500;
}
.filter-btn:hover,
.active-filter {
    background: #1b5e20;
    color: white;
}

/* TABLE */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
}
th, td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: center;
}
th {
    background: #eaf6ea;
    color: #1b5e20;
}

/* DELETE BUTTON */
.btn-delete {
    background: #d32f2f;
    color: white;
    padding: 6px 10px;
    border-radius: 6px;
    text-decoration: none;
}
.btn-delete:hover { background: #9a2121; }

footer {
    text-align: center;
    margin-top: 25px;
    color: #777;
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <h1>💬 Customer Feedback</h1>
    <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR (as per your flow) -->
<div class="sidebar">
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="orders.php">📦 Orders</a>
    <a href="manage_menu.php">🍴 Manage Menu</a>
    <a href="staff.php">👨‍🍳 Staff</a>
    <a href="customers.php">👥 Customers</a>
    <a href="tables.php">🪑 Tables</a>
    <a href="todays_special.php">⭐ Today's Special Menu</a>
    <a href="feedback.php" class="active">💬 Feedback</a>
    <a href="reports.php">📊 Reports</a>
    <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN CONTENT -->
<div class="main">
<div class="container">

    <h2>Customer Feedback</h2>

    <!-- ⭐ RATING FILTER -->
    <div class="filter-box">
        <a href="feedback.php" class="filter-btn <?= $rating_filter=="" ? 'active-filter' : '' ?>">All</a>
        <?php for ($i=5; $i>=1; $i--): ?>
            <a href="feedback.php?rating=<?= $i ?>" 
               class="filter-btn <?= $rating_filter==$i ? 'active-filter' : '' ?>"><?= $i ?> ★</a>
        <?php endfor; ?>
    </div>

    <!-- FEEDBACK TABLE -->
    <table>
        <tr>
            <th>ID</th>
            <th>Customer</th>
            <th>Rating</th>
            <th>Comment</th>
            <th>Date</th>
            <th>Action</th>
        </tr>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['customer_name']) ?></td>
                    <td>
                        <?php for ($i=1; $i<=5; $i++): ?>
                            <?= $i <= $row['rating'] ? "★" : "☆" ?>
                        <?php endfor; ?>
                    </td>
                    <td><?= htmlspecialchars($row['comment']) ?></td>
                    <td><?= date('d M Y, h:i A', strtotime($row['date_submitted'])) ?></td>
                    <td>
                        <a href="feedback.php?delete_id=<?= $row['id'] ?>" class="btn-delete"
                           onclick="return confirm('Delete this feedback?');">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6">No feedback found.</td></tr>
        <?php endif; ?>
    </table>

</div>
</div>

<footer>© <?= date('Y') ?> Restaurant Management System | Admin Panel</footer>

</body>
</html>