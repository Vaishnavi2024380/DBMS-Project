<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Check staff login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../login.php");
    exit;
}

// Validate order ID
if (!isset($_GET['id'])) {
    header("Location: manage_orders.php");
    exit;
}

$order_id = intval($_GET['id']);

// Fetch order details
$order_query = mysqli_query($conn, "SELECT * FROM orders WHERE id=$order_id");
$order = mysqli_fetch_assoc($order_query);

if (!$order) {
    echo "<script>alert('Order not found!'); window.location='manage_orders.php';</script>";
    exit;
}

// Fetch ordered items
$items = mysqli_query($conn, "SELECT * FROM order_items WHERE order_id=$order_id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Order</title>

<style>
body {
    background: #fff6f6;
    font-family: 'Poppins', sans-serif;
    padding: 20px;
}
.box {
    background: white;
    padding: 25px;
    border-radius: 10px;
    max-width: 700px;
    margin: auto;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}
h2 {
    color: #b71c1c;
    text-align: center;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}
th, td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: center;
}
th {
    background: #fff1f1;
    color: #b71c1c;
}
.back-btn {
    display: block;
    margin: 20px auto 0;
    padding: 10px 20px;
    background: #b71c1c;
    color: white;
    border-radius: 8px;
    border: none;
    cursor: pointer;
}
</style>
</head>

<body>

<div class="box">
    <h2>Order Details</h2>

    <p><strong>Order ID:</strong> <?= $order['id'] ?></p>
    <p><strong>Customer:</strong> <?= htmlspecialchars($order['customer_name']) ?></p>
    <p><strong>Table No:</strong> <?= $order['table_no'] ?></p>
    <p><strong>Total Price (₹):</strong> <?= $order['total_price'] ?></p>
    <p><strong>Status:</strong> <?= $order['status'] ?></p>
    <p><strong>Order Date:</strong> <?= $order['order_date'] ?></p>

    <h3>Items</h3>
    <table>
        <tr>
            <th>Item</th>
            <th>Qty</th>
            <th>Price (₹)</th>
        </tr>

        <?php while ($i = mysqli_fetch_assoc($items)): ?>
        <tr>
            <td><?= htmlspecialchars($i['item_name']) ?></td>
            <td><?= $i['quantity'] ?></td>
            <td><?= $i['price'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>

    <button class="back-btn" onclick="window.location='manage_orders.php'">← Back</button>
</div>

</body>
</html>