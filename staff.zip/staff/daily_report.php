<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Check staff login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../login.php");
    exit;
}

$name = $_SESSION['name'];
$today = date('Y-m-d');

// ✅ Fetch data
$total_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM orders WHERE DATE(order_date)='$today'"))['c'];
$delivered = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM orders WHERE status='Delivered' AND DATE(order_date)='$today'"))['c'];
$cancelled = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM orders WHERE status='Cancelled' AND DATE(order_date)='$today'"))['c'];
$revenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_price) AS total FROM orders WHERE status='Delivered' AND DATE(order_date)='$today'"))['total'] ?? 0;

$feedback_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS c FROM feedback WHERE DATE(date_submitted)='$today'"))['c'];
$avg_rating = round(mysqli_fetch_assoc(mysqli_query($conn, "SELECT AVG(rating) AS avg FROM feedback WHERE DATE(date_submitted)='$today'"))['avg'], 1);

$orders_today = mysqli_query($conn, "SELECT * FROM orders WHERE DATE(order_date)='$today' ORDER BY order_date DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Daily Report | Staff Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
body {
  font-family: 'Poppins', sans-serif;
  margin: 0;
  background-color: #fff6f6;
  overflow: hidden; /* Prevent scrolling */
}

/* Header */
.header {
  background: #b71c1c;
  color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 25px;
  font-size: 18px;
  font-weight: 500;
  position: fixed;
  top: 0; left: 0; right: 0;
  z-index: 1000;
}
.header a {
  background: white;
  color: #b71c1c;
  padding: 6px 14px;
  border-radius: 8px;
  text-decoration: none;
  font-size: 14px;
  transition: 0.3s;
}
.header a:hover { background: #f5f5f5; }

/* Sidebar */
.sidebar {
  width: 220px;
  background-color: #fff;
  height: 100vh;
  position: fixed;
  top: 55px;
  left: 0;
  box-shadow: 2px 0 5px rgba(0,0,0,0.1);
}
.sidebar a {
  display: block;
  padding: 12px 20px;
  color: #b71c1c;
  text-decoration: none;
  font-weight: 500;
}
.sidebar a.active {
  background: #b71c1c;
  color: white;
}
.sidebar a:hover {
  background: #ffe6e6;
}

/* Main */
.main {
  margin-left: 240px;
  margin-top: 70px;
  padding: 10px 25px;
  height: calc(100vh - 70px);
  overflow: hidden;
}
h2 {
  color: #b71c1c;
  text-align: center;
  margin: 0 0 15px 0;
}

/* Cards */
.report-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 12px;
  margin-bottom: 10px;
}
.card {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
  padding: 10px;
  text-align: center;
}
.card h3 {
  color: #b71c1c;
  margin: 0;
  font-size: 14px;
}
.card p {
  font-size: 18px;
  font-weight: 600;
  margin: 5px 0 0 0;
}

/* Chart */
.chart-box {
  background: white;
  border-radius: 10px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
  padding: 10px;
  width: 300px;
  margin: 10px auto;
  height: 220px;
}

/* Table */
.table-container {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
  margin-top: 10px;
  padding: 8px;
  height: 200px;
  overflow-y: auto;
}
table {
  width: 100%;
  border-collapse: collapse;
}
th, td {
  padding: 8px;
  text-align: center;
  border-bottom: 1px solid #f0f0f0;
  font-size: 13px;
}
th {
  background: #ffe6e6;
  color: #b71c1c;
}

/* Footer */
footer {
  text-align: center;
  color: #888;
  font-size: 12px;
  margin-top: 5px;
}
</style>
</head>
<body>

<!-- Header -->
<div class="header">
  <span>📊 Daily Report — Staff Dashboard</span>
  <div>
    
    <a href="../logout.php">Logout</a>
  </div>
</div>

<!-- Sidebar -->
<div class="sidebar">
  <a href="home.php">🏠 Home</a>
  <a href="manage_orders.php">📦 Manage Orders</a>
  <a href="kitchen_orders.php">🍳 Kitchen Orders</a>
  <a href="tables.php">🪑 Table Management</a>
  <a href="view_feedback.php">💬 Feedback</a>
  <a href="daily_report.php" class="active">📊 Daily Report</a>
  <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- Main -->
<div class="main">
  <h2>📅 Daily Summary — <?= date('d M Y') ?></h2>

  <div class="report-grid">
    <div class="card"><h3>Total Orders</h3><p><?= $total_orders ?></p></div>
    <div class="card"><h3>Delivered</h3><p><?= $delivered ?></p></div>
    <div class="card"><h3>Cancelled</h3><p><?= $cancelled ?></p></div>
    <div class="card"><h3>Revenue (₹)</h3><p><?= number_format($revenue, 2) ?></p></div>
    <div class="card"><h3>Feedbacks</h3><p><?= $feedback_count ?></p></div>
    <div class="card"><h3>Rating</h3><p><?= $avg_rating ?: 'N/A' ?>⭐</p></div>
  </div>

  <div class="chart-box">
    <canvas id="orderChart"></canvas>
  </div>

  <div class="table-container">
    <table>
      <tr>
        <th>Order ID</th>
        <th>Customer</th>
        <th>Status</th>
        <th>Total (₹)</th>
        <th>Time</th>
      </tr>
      <?php if (mysqli_num_rows($orders_today) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($orders_today)): ?>
          <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['customer_name']) ?></td>
            <td><?= htmlspecialchars($row['status']) ?></td>
            <td><?= number_format($row['total_price'],2) ?></td>
            <td><?= date('h:i A', strtotime($row['order_date'])) ?></td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="5">No orders placed today.</td></tr>
      <?php endif; ?>
    </table>
  </div>

  <footer>© <?= date('Y') ?> Restaurant Management System | Staff Dashboard</footer>
</div>

<!-- Chart -->
<script>
document.addEventListener("DOMContentLoaded", () => {
  const ctx = document.getElementById('orderChart');
  new Chart(ctx, {
    type: 'pie',
    data: {
      labels: ['Delivered', 'Cancelled', 'Pending'],
      datasets: [{
        data: [<?= $delivered ?>, <?= $cancelled ?>, <?= $total_orders - $delivered - $cancelled ?>],
        backgroundColor: ['#4CAF50', '#E53935', '#FFC107']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: 'bottom' }
      }
    }
  });
});
</script>
</body>
</html>