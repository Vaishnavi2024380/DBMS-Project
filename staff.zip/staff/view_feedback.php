<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Check if staff is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../login.php");
    exit;
}

$name = $_SESSION['name'] ?? 'Staff User';

// ✅ Fetch all feedback data
$query = "SELECT * FROM feedback ORDER BY date_submitted DESC";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Customer Feedback | Staff Dashboard</title>
<style>
body {
  font-family: 'Poppins', sans-serif;
  margin: 0;
  background-color: #fff6f6;
}

/* ===== Top Navbar ===== */
.navbar {
  background-color: #b71c1c;
  color: white;
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 18px;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
}
.navbar a {
  color: #b71c1c;
  background: white;
  padding: 8px 14px;
  border-radius: 6px;
  text-decoration: none;
  transition: 0.3s;
  font-weight: 500;
}
.navbar a:hover {
  background: #f5f5f5;
}

/* ===== Sidebar ===== */
.sidebar {
  width: 220px;
  background-color: #ffffff;
  height: 100vh;
  position: fixed;
  top: 55px;
  left: 0;
  box-shadow: 2px 0 5px rgba(0,0,0,0.1);
}
.sidebar a {
  display: block;
  color: #b71c1c;
  padding: 14px 20px;
  text-decoration: none;
  font-weight: 500;
}
.sidebar a:hover {
  background: #ffe6e6;
}
.sidebar a.active {
  background: #b71c1c;
  color: white;
}

/* ===== Main Content ===== */
.main {
  margin-left: 240px;
  margin-top: 80px;
  padding: 20px;
}
h2 {
  color: #b71c1c;
  margin-bottom: 25px;
  text-align: center;
}

/* ===== Feedback Cards ===== */
.feedback-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 20px;
}
.feedback-card {
  background: white;
  border-radius: 10px;
  padding: 18px;
  box-shadow: 0 3px 8px rgba(0,0,0,0.1);
  transition: transform 0.2s;
}
.feedback-card:hover {
  transform: scale(1.02);
}
.feedback-card h3 {
  margin: 0;
  color: #b71c1c;
}
.feedback-card p {
  color: #444;
  font-size: 14px;
}
.stars {
  color: #ffb400;
  font-size: 18px;
  margin: 5px 0;
}
.date {
  font-size: 12px;
  color: #888;
  margin-top: 8px;
  text-align: right;
}

/* ===== Footer ===== */
footer {
  text-align: center;
  color: #777;
  font-size: 14px;
  margin-top: 40px;
}
</style>
</head>
<body>

<!-- ===== Top Navbar ===== -->
<div class="navbar">
  <span>💬 Customer Feedback — Staff Dashboard</span>
  <div>
    
    <a href="../logout.php">Logout</a>
  </div>
</div>

<!-- ===== Sidebar ===== -->
<div class="sidebar">
  <a href="home.php">🏠 Home</a>
  <a href="manage_orders.php">📦 Manage Orders</a>
  <a href="kitchen_orders.php">🍳 Kitchen Orders</a>
  <a href="tables.php">🪑 Table Management</a>
  <a href="view_feedback.php" class="active">💬 Feedback</a>
  <a href="daily_report.php">📊 Daily Report</a>
  <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- ===== Main Content ===== -->
<div class="main">
  <h2>What Customers Say 💬</h2>

  <?php if (mysqli_num_rows($result) > 0): ?>
  <div class="feedback-container">
    <?php while ($row = mysqli_fetch_assoc($result)): ?>
    <div class="feedback-card">
      <h3><?= htmlspecialchars($row['customer_name']) ?></h3>
      <div class="stars">
        <?php for ($i = 1; $i <= 5; $i++): ?>
          <?= $i <= $row['rating'] ? '★' : '☆' ?>
        <?php endfor; ?>
      </div>
      <p>"<?= nl2br(htmlspecialchars($row['comment'])) ?>"</p>
      <div class="date">🕓 <?= date('d M Y, h:i A', strtotime($row['date_submitted'])) ?></div>
    </div>
    <?php endwhile; ?>
  </div>
  <?php else: ?>
  <p style="text-align:center;">No feedback found yet.</p>
  <?php endif; ?>

  <footer>© <?= date('Y') ?> Restaurant Management System | Staff Dashboard</footer>
</div>

</body>
</html>