<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Verify staff login
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'staff') {
    header("Location: ../login.php");
    exit;
}

$name = $_SESSION['name'];

// ✅ Fetch dashboard statistics safely
$total_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM orders"))['count'] ?? 0;
$pending_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM orders WHERE status IN ('Placed','In Progress')"))['count'] ?? 0;
$delivered_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM orders WHERE status='Delivered'"))['count'] ?? 0;
$reserved_tables = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM tables WHERE status='Reserved'"))['count'] ?? 0;
$available_tables = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM tables WHERE status='Available'"))['count'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Staff Dashboard | Restaurant System</title>
<style>
:root {
  --brand: #b71c1c;
  --light: #fff6f6;
  --muted: #fceaea;
  --shadow: rgba(0,0,0,0.1);
}

* { box-sizing: border-box; font-family: 'Poppins', sans-serif; }
body {
  margin: 0;
  background-color: var(--light);
  color: #333;
}

/* ===== HEADER (Top Navbar) ===== */
.header {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 64px;
  background-color: var(--brand);
  color: #fff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 25px;
  z-index: 1000;
  box-shadow: 0 2px 6px var(--shadow);
}
.header .title {
  font-size: 20px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 8px;
}
.header a {
  background: white;
  color: var(--brand);
  padding: 8px 14px;
  border-radius: 8px;
  text-decoration: none;
  font-weight: 600;
  transition: 0.3s;
}
.header a:hover { background: #f5f5f5; }

/* ===== SIDEBAR ===== */
.sidebar {
  position: fixed;
  top: 64px;
  left: 0;
  width: 220px;
  bottom: 0;
  background: #fff;
  box-shadow: 2px 0 6px var(--shadow);
  padding-top: 10px;
}
.sidebar a {
  display: flex;
  align-items: center;
  gap: 10px;
  color: var(--brand);
  padding: 14px 20px;
  text-decoration: none;
  font-weight: 500;
  transition: 0.3s;
}
.sidebar a:hover {
  background: var(--muted);
}
.sidebar a.active {
  background: var(--brand);
  color: #fff;
  border-left: 6px solid #8f1919;
  padding-left: 14px;
}

/* ===== MAIN CONTENT ===== */
.main {
  margin-left: 240px;
  margin-top: 80px;
  padding: 25px;
}
.welcome {
  font-size: 24px;
  font-weight: 600;
  color: var(--brand);
  margin-bottom: 25px;
}

/* ===== DASHBOARD CARDS ===== */
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 20px;
}
.card {
  background: #fff;
  padding: 25px;
  border-radius: 14px;
  box-shadow: 0 4px 10px var(--shadow);
  text-align: center;
  transition: transform 0.25s ease;
}
.card:hover {
  transform: translateY(-4px);
}
.card h3 {
  color: var(--brand);
  font-size: 17px;
  margin-bottom: 10px;
}
.card p {
  font-size: 30px;
  color: #333;
  font-weight: bold;
  margin: 0;
}

/* ===== FOOTER ===== */
footer {
  margin-top: 60px;
  text-align: center;
  color: #888;
  font-size: 14px;
}

/* ===== RESPONSIVE ===== */
@media(max-width:900px){
  .sidebar { width: 64px; }
  .main { margin-left: 64px; }
  .header .title span { display: none; }
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="header">
  <div class="title">👨‍🍳 <span>Restaurant — Staff Panel</span></div>
  <a href="../logout.php">Logout</a>
</div>

<!-- SIDEBAR -->
<div class="sidebar">
  <a href="home.php" class="active">🏠 Home</a>
  <a href="manage_orders.php">📦 Manage Orders</a>
  <a href="kitchen_orders.php">🍳 Kitchen Orders</a>
  <a href="tables.php">🪑 Table Management</a>
  <a href="view_feedback.php">💬 Feedback</a>
  <a href="daily_report.php">📊 Daily Report</a>
  <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- MAIN -->
<div class="main">
  <div class="welcome">Welcome, <?= htmlspecialchars($name) ?> 👋</div>

  <div class="cards">
    <div class="card">
      <h3>Total Orders</h3>
      <p><?= $total_orders ?></p>
    </div>
    <div class="card">
      <h3>Pending Orders</h3>
      <p><?= $pending_orders ?></p>
    </div>
    <div class="card">
      <h3>Delivered Orders</h3>
      <p><?= $delivered_orders ?></p>
    </div>
    <div class="card">
      <h3>Reserved Tables</h3>
      <p><?= $reserved_tables ?></p>
    </div>
    <div class="card">
      <h3>Available Tables</h3>
      <p><?= $available_tables ?></p>
    </div>
  </div>

  <footer>© <?= date('Y') ?> Restaurant Management System | Staff Dashboard</footer>
</div>

</body>
</html>