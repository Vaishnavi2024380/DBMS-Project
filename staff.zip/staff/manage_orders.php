<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// Check staff login
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'staff') {
    header("Location: ../login.php");
    exit;
}
$staff_name = $_SESSION['name'] ?? 'Staff User';

// ✅ ACCEPT / REJECT
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'], $_POST['order_id'])) {

    $order_id    = intval($_POST['order_id']);
    $action      = $_POST['action'];
    $assigned_to = mysqli_real_escape_string($conn, $staff_name);

    if ($action === 'accept') {

        mysqli_query($conn, "UPDATE orders 
            SET assigned_to='$assigned_to', action_status='Accepted', status='Accepted'
            WHERE id=$order_id");

        // Reserve table with customer name
        $ord = mysqli_fetch_assoc(mysqli_query($conn,
            "SELECT table_no, customer_name FROM orders WHERE id=$order_id"));
        if ($ord) {
            $table    = $ord['table_no'];
            $customer = $ord['customer_name'];
            mysqli_query($conn, "UPDATE tables 
                SET status='Reserved', reserved_by='$customer' 
                WHERE table_no='$table'");
        }

    } elseif ($action === 'reject') {

        mysqli_query($conn, "UPDATE orders 
            SET assigned_to='$assigned_to', action_status='Rejected', status='Finished'
            WHERE id=$order_id");

        // Free table
        $t = mysqli_fetch_assoc(mysqli_query($conn,
            "SELECT table_no FROM orders WHERE id=$order_id"));
        if ($t) {
            $table = $t['table_no'];
            mysqli_query($conn, "UPDATE tables 
                SET status='Available', reserved_by=NULL 
                WHERE table_no='$table'");
        }
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ✅ STATUS UPDATE (dropdown)
if (isset($_POST['update_status'])) {

    $order_id   = intval($_POST['order_id']);
    $new_status = mysqli_real_escape_string($conn, $_POST['new_status']);

    // Added "Cancelled"
    $allowed = ['Placed','Accepted','In Progress','Ready to Serve','Delivered','Finished','Cancelled'];

    if (in_array($new_status, $allowed)) {

        mysqli_query($conn, "UPDATE orders SET status='$new_status' WHERE id=$order_id");

        // Get table + customer
        $order = mysqli_fetch_assoc(mysqli_query($conn,
            "SELECT table_no, customer_name FROM orders WHERE id=$order_id"));

        if ($order && $order['table_no']) {

            $table    = $order['table_no'];
            $customer = $order['customer_name'];

            // Placed / Accepted / In Progress / Ready → Reserved
            if (in_array($new_status, ['Placed','Accepted','In Progress','Ready to Serve'])) {
                mysqli_query($conn, "UPDATE tables 
                    SET status='Reserved', reserved_by='$customer' 
                    WHERE table_no='$table'");
            }

            // Delivered → Occupied
            elseif ($new_status == 'Delivered') {
                mysqli_query($conn, "UPDATE tables 
                    SET status='Occupied', reserved_by='$customer' 
                    WHERE table_no='$table'");
            }

            // Finished or Cancelled → Available
            elseif (in_array($new_status, ['Finished','Cancelled'])) {
                mysqli_query($conn, "UPDATE tables 
                    SET status='Available', reserved_by=NULL 
                    WHERE table_no='$table'");
            }
        }
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// ✅ Fetch all orders
$orders = mysqli_query($conn, "SELECT * FROM orders ORDER BY order_date DESC");
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Manage Orders | Staff Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
:root{
  --brand:#b71c1c;
  --brand-dark:#8f1919;
  --muted:#f5f5f5;
  --accent:#1976d2;
}
*{box-sizing:border-box;font-family:'Poppins',sans-serif;}
body{margin:0;background:#fff6f6;color:#333;}
.header{
  position:fixed;top:0;left:0;right:0;height:64px;
  background:var(--brand);color:#fff;
  display:flex;align-items:center;justify-content:space-between;
  padding:0 18px;z-index:1000;box-shadow:0 2px 6px rgba(0,0,0,.08);
}
.header .brand{display:flex;align-items:center;gap:14px;font-size:20px;font-weight:700;}
.header .logo{width:36px;height:36px;border-radius:6px;background:rgba(255,255,255,0.08);display:flex;align-items:center;justify-content:center;font-size:18px;}
.header .btn{background:#fff;color:var(--brand);padding:8px 12px;border-radius:6px;text-decoration:none;font-weight:600;}
.header .btn:hover{background:#f5f5f5;}

.sidebar{
  position:fixed;top:64px;left:0;width:220px;bottom:0;background:#fff;
  border-right:1px solid #eee;padding-top:18px;z-index:900;
}
.sidebar a{display:flex;align-items:center;gap:10px;padding:12px 18px;color:var(--brand);text-decoration:none;font-weight:500;}
.sidebar a:hover{background:var(--muted);}
.sidebar a.active{background:var(--brand);color:#fff;border-left:6px solid var(--brand-dark);padding-left:12px;}

.main{margin-left:220px;margin-top:64px;padding:22px;min-height:calc(100vh - 64px);}
.page-title{color:var(--brand);font-size:22px;margin-bottom:14px;font-weight:700;}
.table-wrap{background:#fff;border-radius:10px;box-shadow:0 3px 10px rgba(0,0,0,.06);overflow:auto;padding:6px;}
table{width:100%;border-collapse:collapse;}
th,td{padding:10px 12px;text-align:center;border-bottom:1px solid #f0f0f0;font-size:14px;}
th{background:#fff1f1;color:var(--brand);font-weight:700;}

.form-inline{display:flex;gap:8px;align-items:center;justify-content:center;}
select{padding:8px 10px;border-radius:8px;border:1px solid #dcdcdc;background:#fff;min-width:140px;font-weight:600;}
.btn-save{background:var(--accent);color:#fff;border:none;padding:8px 12px;border-radius:8px;cursor:pointer;}

.action-btn{border:none;padding:8px 12px;border-radius:8px;color:#fff;cursor:pointer;margin:0 4px;font-weight:700}
.accept{background:#2e7d32}
.reject{background:#d32f2f}
.view-btn{background:#1976d2;color:#fff;padding:8px 12px;border-radius:8px;text-decoration:none;font-weight:700;}
.badge-accepted{background:linear-gradient(#4caf50,#2e7d32);color:#fff;padding:8px 14px;border-radius:20px;font-weight:700}
.badge-rejected{background:linear-gradient(#f44336,#c62828);color:#fff;padding:8px 14px;border-radius:20px;font-weight:700}
.badge-cancelled{
    background:#ffe5e5; 
    color:#b71c1c;
    padding:8px 14px;
    border-radius:20px;
    border:1px solid #b71c1c;
    font-weight:700;
}
</style>
</head>

<body>

<div class="header">
  <div class="brand">
    <div class="logo">🍽️</div>
    <div><span>Restaurant —</span> Staff</div>
  </div>
  <div>
    
    <a class="btn" href="../logout.php">Logout</a>
  </div>
</div>

<nav class="sidebar">
  <a href="home.php">🏠 Home</a>
  <a href="manage_orders.php" class="active">📋 Manage Orders</a>
  <a href="kitchen_orders.php">🍳 Kitchen Orders</a>
  <a href="tables.php">🪑 Table Management</a>
  <a href="view_feedback.php">💬 Feedback</a>
  <a href="daily_report.php">📊 Daily Reports</a>
  <a href="change_password.php">🔑 Change Password</a>
</nav>

<main class="main">
  <div class="page-title">All Customer Orders</div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Order ID</th>
          <th>Customer</th>
          <th>Table No</th>
          <th>Total Price (₹)</th>
          <th>Assigned To</th>
          <th>Status</th>
          <th>View</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
      <?php while ($row = mysqli_fetch_assoc($orders)): ?>
      <tr>
        <td><?= $row['id'] ?></td>
        <td><?= htmlspecialchars($row['customer_name']) ?></td>
        <td><?= htmlspecialchars($row['table_no']) ?></td>
        <td><?= number_format($row['total_price'],2) ?></td>
        <td><?= htmlspecialchars($row['assigned_to'] ?: '-') ?></td>

        <!-- STATUS DROPDOWN -->
        <td>
          <form method="POST">
            <input type="hidden" name="order_id" value="<?= $row['id'] ?>">
            <div class="form-inline">
              <select name="new_status">
                <option value="Placed"        <?=($row['status']=='Placed')?'selected':''?>>Placed</option>
                <option value="Accepted"      <?=($row['status']=='Accepted')?'selected':''?>>Accepted</option>
                <option value="In Progress"   <?=($row['status']=='In Progress')?'selected':''?>>In Progress</option>
                <option value="Ready to Serve"<?=($row['status']=='Ready to Serve')?'selected':''?>>Ready to Serve</option>
                <option value="Delivered"     <?=($row['status']=='Delivered')?'selected':''?>>Delivered</option>
                <option value="Finished"      <?=($row['status']=='Finished')?'selected':''?>>Finished</option>
                <option value="Cancelled"     <?=($row['status']=='Cancelled')?'selected':''?>>Cancelled</option>
              </select>
              <button type="submit" name="update_status" class="btn-save">Save</button>
            </div>
          </form>
        </td>

        <!-- VIEW BUTTON -->
        <td>
          <a href="view_order.php?id=<?= $row['id'] ?>" class="view-btn">View</a>
        </td>

        <!-- ACTION COLUMN -->
        <td>
          <?php if($row['status']=='Cancelled'): ?>
            <div class="badge-cancelled">Cancelled by Customer</div>

          <?php elseif(empty($row['action_status'])): ?>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="order_id" value="<?=$row['id']?>">
              <button name="action" value="accept" class="action-btn accept">Accept</button>
              <button name="action" value="reject" class="action-btn reject">Reject</button>
            </form>

          <?php elseif($row['action_status']=='Accepted'): ?>
            <div class="badge-accepted">Accepted</div>

          <?php elseif($row['action_status']=='Rejected'): ?>
            <div class="badge-rejected">Rejected</div>
          <?php endif; ?>
        </td>

      </tr>
      <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</main>

</body>
</html>