<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Verify login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../login.php");
    exit;
}

$name = $_SESSION['name'];
$message = "";

// ✅ Handle Password Change
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current = mysqli_real_escape_string($conn, $_POST['current_password']);
    $new = mysqli_real_escape_string($conn, $_POST['new_password']);
    $confirm = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    // Fetch current password from DB
    $query = "SELECT password FROM users WHERE name='$name' AND role='staff'";
    $result = mysqli_query($conn, $query);
    $user = mysqli_fetch_assoc($result);

    if (!$user) {
        $message = "<p class='error'>❌ User not found!</p>";
    } elseif ($new !== $confirm) {
        $message = "<p class='error'>⚠️ New passwords do not match!</p>";
    } elseif ($current !== $user['password']) { // Plain password check (can use md5 if hashed)
        $message = "<p class='error'>❌ Incorrect current password!</p>";
    } else {
        mysqli_query($conn, "UPDATE users SET password='$new' WHERE name='$name' AND role='staff'");
        $message = "<p class='success'>✅ Password changed successfully!</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Change Password | Staff Dashboard</title>
<style>
body {
  font-family: 'Poppins', sans-serif;
  margin: 0;
  background: #fff6f6;
}
.navbar {
  background-color: #b71c1c;
  color: white;
  padding: 15px 30px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 18px;
}
.navbar a {
  background: white;
  color: #b71c1c;
  padding: 8px 14px;
  border-radius: 6px;
  text-decoration: none;
  transition: 0.3s;
  font-weight: 500;
}
.navbar a:hover { background: #f5f5f5; }

.sidebar {
  width: 220px;
  background-color: #ffffff;
  height: 100vh;
  position: fixed;
  top: 55px;
  left: 0;
  box-shadow: 2px 0 5px rgba(0,0,0,0.1);
}
.sidebar a {
  display: block;
  color: #b71c1c;
  padding: 14px 20px;
  text-decoration: none;
  font-weight: 500;
}
.sidebar a:hover { background: #ffe6e6; }
.sidebar a.active { background: #b71c1c; color: white; }

.main {
  margin-left: 240px;
  margin-top: 80px;
  padding: 20px;
}
h2 {
  color: #b71c1c;
  text-align: center;
  margin-bottom: 20px;
}
.form-box {
  background: white;
  max-width: 450px;
  margin: auto;
  padding: 25px;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}
label {
  display: block;
  margin-bottom: 6px;
  color: #333;
  font-weight: 500;
}
input[type=password] {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border-radius: 8px;
  border: 1px solid #ccc;
}
button {
  width: 100%;
  background: #b71c1c;
  color: white;
  border: none;
  padding: 10px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 16px;
  font-weight: 500;
}
button:hover { background: #a31515; }
.success {
  background: #e8f5e9;
  color: #2e7d32;
  padding: 10px;
  border-radius: 6px;
  text-align: center;
}
.error {
  background: #ffebee;
  color: #c62828;
  padding: 10px;
  border-radius: 6px;
  text-align: center;
}
footer {
  text-align: center;
  color: #888;
  font-size: 14px;
  margin-top: 40px;
}
</style>
</head>
<body>

<div class="navbar">
  <span>🔑 Change Password — Staff Dashboard</span>
  <div>
    
    <a href="../logout.php">Logout</a>
  </div>
</div>

<div class="sidebar">
  <a href="home.php">🏠 Home</a>
  <a href="manage_orders.php">📦 Manage Orders</a>
  <a href="kitchen_orders.php">🍳 Kitchen Orders</a>
  <a href="table_management.php">🪑 Table Management</a>
  <a href="view_feedback.php">💬 Feedback</a>
  <a href="daily_report.php">📊 Daily Report</a>
  <a href="change_password.php" class="active">🔑 Change Password</a>
</div>

<div class="main">
  <h2>Change Your Password</h2>
  <div class="form-box">
    <?= $message ?>
    <form method="POST">
      <label>Current Password</label>
      <input type="password" name="current_password" required>

      <label>New Password</label>
      <input type="password" name="new_password" required minlength="4">

      <label>Confirm New Password</label>
      <input type="password" name="confirm_password" required minlength="4">

      <button type="submit">Update Password</button>
    </form>
  </div>
  <footer>© <?= date('Y') ?> Restaurant Management System | Staff Panel</footer>
</div>

</body>
</html>