<?php  
session_start();  
require_once __DIR__ . '/../config/db.php';  

// ✅ Staff login check  
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'staff') {  
    header("Location: ../login.php");  
    exit;  
}  

$staff_name = $_SESSION['name'] ?? 'Staff';  

// ❌ Removed update status handler because you don't want update column
// (Keeping it optional. You can add later if needed)

// ✅ Fetch all tables  
$tables = mysqli_query($conn, "SELECT * FROM tables ORDER BY table_no ASC");  
?>  

<!DOCTYPE html>  
<html lang="en">  
<head>  
<meta charset="UTF-8">  
<title>Table Management | Staff Dashboard</title>  
<style>  
:root{  
  --brand:#b71c1c;  
  --brand-dark:#8f1919;  
  --muted:#f5f5f5;  
  --accent:#1976d2;  
}  
body{  
  font-family:'Poppins',sans-serif;  
  margin:0;  
  background:#fff6f6;  
  color:#333;  
}  

/* HEADER */  
.header{  
  background:var(--brand);  
  color:white;  
  display:flex;  
  justify-content:space-between;  
  align-items:center;  
  padding:15px 25px;  
  position:fixed;  
  top:0;left:0;right:0;  
  z-index:1000;  
}  
.header h1{font-size:20px;margin:0;}  
.header a{  
  background:white;  
  color:var(--brand);  
  padding:8px 14px;  
  border-radius:6px;  
  text-decoration:none;  
  font-weight:600;  
}  
.header a:hover{background:#f8f8f8;}  

/* SIDEBAR */  
.sidebar{  
  background:white;  
  width:220px;  
  height:100vh;  
  position:fixed;  
  top:60px;left:0;  
  border-right:1px solid #a71919ff;  
  padding-top:20px;  
}  
.sidebar a{  
  display:block;  
  padding:12px 20px;  
  color:var(--brand);  
  text-decoration:none;  
  font-weight:500;  
}  
.sidebar a.active{background:var(--brand);color:white;}  
.sidebar a:hover{background:#f5f5f5;}  

/* MAIN */  
.main{  
  margin-left:240px;  
  margin-top:80px;  
  padding:20px;  
}  
h2{color:var(--brand);margin-bottom:20px;}  

/* TABLE VIEW */  
.table-box{  
  background:white;  
  border-radius:10px;  
  box-shadow:0 3px 10px rgba(0,0,0,0.1);  
  padding:20px;  
}  
table{  
  width:100%;  
  border-collapse:collapse;  
}  
th,td{  
  padding:12px;  
  text-align:center;  
  border-bottom:1px solid #d81111ff;  
}  
th{  
  background:#ffe6e6;  
  color:var(--brand);  
}  

/* Status colors */  
.status-available{color:#2e7d32;font-weight:600;}  
.status-reserved{color:#d32f2f;font-weight:600;}  
.status-occupied{color:#f57c00;font-weight:600;}  
.status-cleaning{color:#0288d1;font-weight:600;}  

footer{  
  text-align:center;  
  color:#777;  
  margin-top:30px;  
}  
</style>  
</head>  
<body>  

<div class="header">  
  <h1>🪑 Table Management — Staff</h1>  
  <a href="../logout.php">Logout</a>  
</div>  

<div class="sidebar">  
  <a href="home.php">🏠 Home</a>  
  <a href="manage_orders.php">📋 Manage Orders</a>  
  <a href="kitchen_orders.php">🍳 Kitchen Orders</a>  
  <a href="tables.php" class="active">🪑 Table Management</a>  
  <a href="view_feedback.php">💬 Feedback</a>  
  <a href="daily_report.php">📊 Daily Reports</a>  
  <a href="change_password.php">🔑 Change Password</a>  
</div>  

<div class="main">  
  <h2>Manage Restaurant Tables</h2>  

  <div class="table-box">  
    <table>  
      <thead>  
        <tr>  
          <th>Table ID</th>  
          <th>Table Number</th>  
          <th>Status</th>  
          <th>Reserved By</th>  
        </tr>  
      </thead>  

      <tbody>  
      <?php while ($row = mysqli_fetch_assoc($tables)): ?>  
        <tr>  
          <td><?= $row['id'] ?></td>  
          <td><?= htmlspecialchars($row['table_no']) ?></td>  
          <td class="status-<?= strtolower(str_replace(' ', '', $row['status'])) ?>">  
            <?= htmlspecialchars($row['status']) ?>  
          </td>  
          <td><?= htmlspecialchars($row['reserved_by'] ?: '-') ?></td>  
        </tr>  
      <?php endwhile; ?>  
      </tbody>  

    </table>  
  </div>  

  <footer>© <?= date('Y') ?> Restaurant Management System | Staff Table Control</footer>  
</div>  

</body>  
</html>