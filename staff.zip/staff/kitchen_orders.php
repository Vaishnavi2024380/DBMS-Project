<?php
session_start();
require_once __DIR__ . '/../config/db.php';

// ✅ Verify staff login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'staff') {
    header("Location: ../login.php");
    exit;
}

$name = $_SESSION['name'];

// ✅ Handle status updates
if (isset($_POST['order_id'], $_POST['new_status'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = mysqli_real_escape_string($conn, $_POST['new_status']);
    mysqli_query($conn, "UPDATE orders SET status='$new_status', assigned_to='$name' WHERE id=$order_id");
    header("Location: kitchen_orders.php");
    exit;
}

// ✅ Fetch orders for both sections
$cooking_orders = mysqli_query($conn, "SELECT * FROM orders WHERE status IN ('Accepted', 'In Progress') ORDER BY order_date DESC");
$ready_orders = mysqli_query($conn, "SELECT * FROM orders WHERE status = 'Ready to Serve' ORDER BY order_date DESC");

// ✅ Latest order ID for alert
$row = mysqli_fetch_assoc(mysqli_query($conn, "SELECT MAX(id) as max_id FROM orders WHERE status='Accepted'"));
$latest_order_id = $row['max_id'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Kitchen Orders | Staff Panel</title>
<style>
:root {
  --brand: #b71c1c;
  --light: #fff6f6;
  --shadow: rgba(0,0,0,0.1);
}
* { font-family: 'Poppins', sans-serif; box-sizing: border-box; }

body {
  margin: 0;
  background: var(--light);
}

/* ===== HEADER ===== */
.header {
  background: var(--brand);
  color: #fff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 30px;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  box-shadow: 0 2px 6px var(--shadow);
  z-index: 100;
}
.header-title {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 20px;
  font-weight: 600;
}
.header-buttons {
  display: flex;
  gap: 10px;
}
.header a {
  background: white;
  color: var(--brand);
  padding: 8px 14px;
  border-radius: 8px;
  text-decoration: none;
  font-weight: 600;
}
.header a:hover { background: #f5f5f5; }

/* ===== SIDEBAR ===== */
.sidebar {
  position: fixed;
  top: 60px;
  left: 0;
  bottom: 0;
  width: 220px;
  background: #fff;
  box-shadow: 2px 0 6px var(--shadow);
}
.sidebar a {
  display: block;
  color: var(--brand);
  padding: 14px 20px;
  text-decoration: none;
  font-weight: 500;
}
.sidebar a:hover { background: #ffe6e6; }
.sidebar a.active {
  background: var(--brand);
  color: white;
  border-left: 6px solid #8f1919;
}

/* ===== MAIN ===== */
.main {
  margin-left: 240px;
  margin-top: 80px;
  padding: 20px;
}
h2 {
  color: var(--brand);
  margin-bottom: 10px;
  text-align: center;
}
.section-title {
  color: #b71c1c;
  font-size: 18px;
  margin-top: 20px;
  margin-bottom: 10px;
  border-left: 5px solid #b71c1c;
  padding-left: 10px;
}

/* ===== ORDER CARDS ===== */
.order-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 20px;
}
.order-card {
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 8px var(--shadow);
  padding: 20px;
  transition: transform 0.2s;
}
.order-card:hover { transform: scale(1.02); }
.order-card h3 { margin: 0; color: var(--brand); }
.order-card p { margin: 5px 0; font-size: 14px; }

.badge {
  padding: 5px 10px;
  border-radius: 20px;
  color: white;
  font-size: 13px;
}
.accepted { background: #f9a825; }
.inprogress { background: #0288d1; }
.ready { background: #43a047; }

.btn {
  border: none;
  padding: 6px 12px;
  border-radius: 8px;
  color: white;
  cursor: pointer;
  font-weight: 500;
  margin-right: 5px;
}
.start { background: #f57c00; }
.ready-btn { background: #43a047; }
.deliver { background: #2e7d32; }
.btn:hover { opacity: 0.9; }

footer {
  margin-top: 40px;
  text-align: center;
  color: #777;
  font-size: 14px;
}
</style>
</head>
<body>

<!-- Header -->
<div class="header">
  <div class="header-title">🍽️ Restaurant — Staff</div>

  <div class="header-buttons">
    
    <a href="../logout.php">Logout</a>
  </div>
</div>

<!-- Sidebar -->
<div class="sidebar">
  <a href="home.php">🏠 Home</a>
  <a href="manage_orders.php">📦 Manage Orders</a>
  <a href="kitchen_orders.php" class="active">🍳 Kitchen Orders</a>
  <a href="tables.php">🪑 Table Management</a>
  <a href="view_feedback.php">💬 Feedback</a>
  <a href="daily_report.php">📊 Daily Report</a>
  <a href="change_password.php">🔑 Change Password</a>
</div>

<!-- Main -->
<div class="main">
  <h2>Kitchen Dashboard</h2>

  <!-- 🍳 COOKING SECTION -->
  <div class="section-title">👨‍🍳 Currently Cooking</div>
  <div class="order-grid">
    <?php if (mysqli_num_rows($cooking_orders) > 0): ?>
      <?php while ($o = mysqli_fetch_assoc($cooking_orders)): ?>
        <div class="order-card">
          <h3>Order #<?= $o['id'] ?> — Table <?= $o['table_no'] ?></h3>
          <p><strong>Customer:</strong> <?= htmlspecialchars($o['customer_name']) ?></p>

          <p><strong>Items:</strong></p>
          <ul style="margin-left:15px;">
          <?php
          $items = mysqli_query($conn,
          "SELECT item_name, quantity FROM order_items WHERE order_id=".$o['id']);
          while($it = mysqli_fetch_assoc($items)):
          ?>
            <li><?= $it['item_name'] ?> × <?= $it['quantity'] ?></li>
          <?php endwhile; ?>
          </ul>

          <p><strong>Status:</strong>
            <span class="badge <?= strtolower(str_replace(' ', '', $o['status'])) ?>">
              <?= ucfirst($o['status']) ?>
            </span>
          </p>

          <form method="POST">
            <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
            <?php if ($o['status'] == 'Accepted'): ?>
              <button class="btn start" name="new_status" value="In Progress">Start Cooking</button>
            <?php elseif ($o['status'] == 'In Progress'): ?>
              <button class="btn ready-btn" name="new_status" value="Ready to Serve">Mark Ready</button>
            <?php endif; ?>
          </form>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p style="text-align:center;">No ongoing cooking orders.</p>
    <?php endif; ?>
  </div>

  <!-- 🚚 READY TO DELIVER SECTION -->
  <div class="section-title">🚚 Ready to Deliver</div>
  <div class="order-grid">
    <?php if (mysqli_num_rows($ready_orders) > 0): ?>
      <?php while ($r = mysqli_fetch_assoc($ready_orders)): ?>
        <div class="order-card">
          <h3>Order #<?= $r['id'] ?> — Table <?= $r['table_no'] ?></h3>
          <p><strong>Customer:</strong> <?= htmlspecialchars($r['customer_name']) ?></p>

          <p><strong>Items:</strong></p>
          <ul style="margin-left:15px;">
          <?php
          $items = mysqli_query($conn,
          "SELECT item_name, quantity FROM order_items WHERE order_id=".$r['id']);
          while($it = mysqli_fetch_assoc($items)):
          ?>
            <li><?= $it['item_name'] ?> × <?= $it['quantity'] ?></li>
          <?php endwhile; ?>
          </ul>

          <p><strong>Status:</strong>
            <span class="badge ready">Ready to Serve</span>
          </p>

          <form method="POST">
            <input type="hidden" name="order_id" value="<?= $r['id'] ?>">
            <button class="btn deliver" name="new_status" value="Delivered">Mark Delivered</button>
          </form>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p style="text-align:center;">No ready-to-serve orders yet.</p>
    <?php endif; ?>
  </div>

  <footer>© <?= date('Y') ?> Restaurant Management System | Kitchen Dashboard</footer>
</div>

</body>
</html>